# Example inputs (all fictional)

The three JSON files in this directory only demonstrate the script input structure:

- `feasibility-input.example.json`: feasibility scoring input.
- `evidence-ledger.example.json`: evidence-ledger input.
- `requirement-brief.example.json`: requirement-brief input.

**Notes:**

- All projects, people, organizations, systems, and numbers are fictional examples.
- In the evidence ledger, `example.gov`, placeholder organizations, and placeholder guidance are not real sources and must not be cited.
- Scores/conclusions in the examples are for demonstration only and represent no real project or industry judgment.
- When copying a template, first replace all placeholder content with facts or verified sources the user provided; keep "to-confirm" for anything missing.

Command examples are in `../scripts/README.md`.
