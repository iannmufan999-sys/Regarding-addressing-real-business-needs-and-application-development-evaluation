# Delivery Playbook: From Diagnosis to Launch

This manual describes a tailorable delivery path. Phase durations are **suggested starting points**, not industry benchmarks; adjust by project size, compliance, data, and team capability.

## 1. Phase overview

| Phase | Goal | Suggested duration | Exit criteria |
|---|---|---|---|
| 0 Discovery | Restore scenario, confirm real need | 1–3 days | Fact ledger + initial hard-gate read |
| 1 Feasibility | Judge worth-doing and doability | 2–5 days | Feasibility memo + decision |
| 2 PoC | Validate key assumptions in minimal scope | 2–6 weeks | Hit preset metrics / clear stop |
| 3 Pilot | Use in a real process at small scale | 4–8 weeks | Quality/cost/ops pass, can scale |
| 4 Productionize | Stable, operable, auditable | By scale | Launch review passed + handover done |

Don't skip phase 1 and go straight to PoC; don't treat PoC as a production system. Every phase needs a "continue/stop/narrow" decision point.

## 2. Phase 0: Discovery

### Outputs

- Scenario boundary and process retrospective.
- Fact ledger: confirmed / to-confirm / assumption / suggestion.
- Surface request → real need → business outcome → non-goal.
- 6 hard gates as pass/fail/unknown.
- Next-step verification list (who, when, what evidence).

### Exit criteria

- A named business owner exists.
- A recent case that can be replayed (or explicit statement that only a hypothetical walkthrough is possible).
- Know where data is, who can authorize, who does evaluation.
- Know what phase 1 will NOT do.

## 3. Phase 1: Feasibility

### Outputs

- 7-dimension scoring + evidence level from `feasibility-rubric.md`.
- Hard-gate table and cap reasons.
- 2–3 candidate options (including "don't invest / optimize process first").
- Risks, unknowns, counter-examples, exit costs.
- Clear recommendation: proceed to PoC / validate first / discovery only / hold.

### Exit criteria

- Business owner, tech lead, risk roles have a clear opinion (not necessarily agreement).
- Key unknowns have a verification plan; blockers have an owner.
- If PoC recommended, the single core assumption PoC must validate is written.

## 4. Phase 2: PoC

### 4.1 PoC plan template

```markdown
# PoC Plan: <name>
## 1. Assumption to validate
- We believe: <user/business> needs <capability> in <scenario>.
- If <key condition> holds, the approach is feasible; otherwise stop.
## 2. Scope
- One user group: <...>
- One workflow: <...>
- One measurable goal: <...>
- Explicitly NOT doing: <...>
## 3. Baseline
- Current manual/legacy metric: <...>
- Measurement method: <...>
## 4. Evaluation
- Eval set: <source/scale/slice>
- Metrics: <task success/quality/latency/cost/safety>
- Pass/fail line: <...>
- Human review: <who/frequency/disagreement handling>
## 5. Implementation
- Reuse existing systems: <...>
- New candidate tools: <...> (tag "candidate", with alternatives)
- Data/permissions: <...>
- Guardrails/rollback: <...>
## 6. Run
- Time: <...>
- Participants: <...>
- Daily/weekly checks: <...>
## 7. Decision
- Continue condition: <...>
- Stop condition: <...>
- Decision-maker / date: <...>
```

### 4.2 PoC scope discipline

- Validate only one core assumption; don't do "platform + multi-scenario + multi-model" at once.
- Use real/desensitized data, not pure sample data.
- Offline evaluation first, then small-traffic shadow/canary.
- Record failure samples, not just successes.
- Weekly retrospective: metrics, failure modes, cost, risk, next step.

### 4.3 Exit criteria

- Hit preset quality/task metrics, with acceptable cost/latency.
- Failure modes have fallback; human review is operable.
- Business side willing to enter pilot; ops side accepts handover.
- Or: explicitly stop, with reasons and reusable assets written down.

## 5. Phase 3: Pilot

### Goal

In a real process, with real users, in limited scope, validate: is quality stable, do users want to use it, can ops handle it, is risk controllable.

### Pilot design

- Pick one department/team/region, not full rollout.
- Shadow mode: AI suggests, human decides; compare AI vs human.
- Canary: gradually expand ratio; set a stop line.
- Human fallback: who watches, how long, how, how to give feedback.
- User feedback: telemetry + interviews + error classification, not just positive ratings.
- Weekly report: quality, latency, cost, adoption, transfer-to-human rate, incidents.

### Exit criteria

- Quality/cost/latency threshold met for 2–4 consecutive weeks.
- Adoption/task metrics hit agreed values, with business-owner confirmation.
- Incidents/privilege-escalation/sensitive-info events within acceptable range, with improvement.
- Ops/docs/training/support ready.

## 6. Phase 4: Productionize

### 6.1 Launch review

- Business: metrics, owner, process change, training.
- Tech: capacity, latency, availability, degradation, rollback.
- Data: permissions, quality, updates, deletion, backup.
- Security/compliance: classification, review, retention, appeal.
- Ops: on-call, SLA, incident response, cost budget.
- Evaluation: regression set, launch threshold, continuous assessment.

### 6.2 Observability metrics

| Category | Metrics |
|---|---|
| Quality | Task success rate, error rate, refusal rate, citation correctness, human-review agreement |
| Usage | Active users, task volume, adoption rate, transfer-to-human rate, retention |
| Performance | P50/P95 latency, timeout rate, tool failure rate |
| Cost | Per-task cost, token/retrieval/tool/human-review cost, budget consumption |
| Security | Privilege escalation, sensitive info, prompt injection, abnormal tool calls, incident count |
| Operations | Knowledge-update timeliness, ticket volume, rollback count, change-failure rate |

### 6.3 Release & rollback

- Versioning: prompts, models, indexes, tools, eval sets all versioned.
- Release: canary; small traffic first, then expand.
- Rollback: one-click revert to previous version; data/index rollback-able; human fallback can take over.
- Kill switch: immediately disable on business/security/cost anomalies.
- Change log: who, when, what changed, why, impact assessment.

## 7. Roles & RACI

| Role | Responsibility |
|---|---|
| Business owner | Define value/metric/scope; bear business outcome; decide continue/stop |
| Product / delivery lead | Scenario, requirements, scope, acceptance, cross-team coordination |
| Tech lead | Architecture, integration, performance, security, technical risk |
| Data / knowledge lead | Data quality, permissions, updates, labeling/ground truth |
| Evaluation lead | Eval set, metrics, human review, regression |
| Security / compliance | Data classification, review, controls, incident response |
| Operations lead | Post-launch process, training, support, SLA, feedback |
| Frontline user | Provide real cases, trial, feedback |

RACI must at least clarify who is Responsible (R), Accountable (A), Consulted (C), Informed (I). Avoid "everyone is responsible".

## 8. Data & evaluation assets

- **Data card**: source, scope, time, fields, sensitivity level, rights, quality, updates.
- **Eval set**: version, sample source, labeling guide, disagreement records, slices.
- **Prompt/model card**: version, purpose, limits, known failure modes.
- **Index card**: corpus version, chunk/embed/rerank config, update records.
- **Cost model**: unit price, magnitude, peak, human review, retry, cache.
- **Runbook**: start/stop, rollback, common failures, contacts, escalation path.

## 9. Risk register

| Risk | Signal | Mitigation |
|---|---|---|
| Value doesn't hold | Users don't use it, metrics don't move | Back to discovery; narrow scope; stop |
| Data unavailable / poor quality | Insufficient coverage, conflicts, gaps | Data due diligence; add data; change scope |
| Evaluation not trustworthy | No ground truth, large labeling disagreement | Build eval set; dual labeling; human review |
| Hallucination / wrong citation | Answer without basis, wrong citation | Force citation; refusal; retrieval/prompt improvement |
| Privilege escalation / prompt injection | Accessing data/tools it shouldn't | Least privilege; filtering; sandbox; red team |
| Cost/latency out of control | High per-task cost, P95 over line | Cache/routing/batch/degrade; narrow scope |
| Vendor lock-in | High migration cost, insufficient SLA | Abstraction layer; exit plan; multi-vendor |
| Ops absence | No one updates/on-calls/handles feedback | Clear owner; SLA; training; handover |
| Compliance blocker | Review fails / no authorization | Stop; remediate; alternative |

## 10. Handover checklist

- [ ] Business owner, ops owner, tech owner clear.
- [ ] Architecture diagram, data-flow diagram, permission model, interface contract.
- [ ] Prompt/model/index/tool/eval-set versions and change records.
- [ ] Evaluation report, known failure modes, open issues.
- [ ] Monitoring dashboard, alert thresholds, on-call roster.
- [ ] Rollback / kill switch / incident-response drill records.
- [ ] Cost model and budget.
- [ ] User training, FAQ, feedback channel.
- [ ] Compliance/security review records and retention/deletion policy.

## 11. 30/60/90-day suggestion (tailor by project)

- **0–30 days**: discovery + feasibility + evaluation-set prototype; don't build an all-encompassing platform.
- **31–60 days**: narrow PoC; offline eval + shadow mode; weekly failure retrospective.
- **61–90 days**: pilot; ops/guardrails/rollback; decide scale / narrow / stop.

Don't treat "launch" as the finish line. Post-launch knowledge updates, quality regression, cost control, and incident response are part of delivery.
