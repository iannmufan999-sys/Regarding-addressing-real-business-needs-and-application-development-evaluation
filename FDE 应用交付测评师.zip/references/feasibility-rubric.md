# Feasibility Scoring & Hard-Gate Manual

This manual provides an explainable, reviewable evaluation method. **Scores are only for structured discussion, not a substitute for the final judgment.** Any conclusion must be jointly confirmed by the business owner, tech lead, and relevant risk roles; when disagreements exist, preserve them — do not paper over with an average.

## 1. Evaluation order

1. Confirm the 6 hard gates first (pass / fail / unknown).
2. Then score the 7 dimensions 0–5 and label the evidence level.
3. Compute raw and evidence-adjusted scores using weights.
4. Apply cap rules to get the "script signal".
5. Human review: add counter-examples, unknowns, reversibility, and exit cost; write the final recommendation.

Gates first, then scoring. **A hard-gate `fail` cannot be offset by a high technical dimension score.**

## 2. The six hard gates

| Gate | Minimum evidence for pass | Typical fail case | Handling of unknown |
|---|---|---|---|
| G1 Business owner | Named owner; problem backed by cases/data; can decide scope and budget | No owner, or merely "lead wants it" | Convert to "find owner + one case retrospective" |
| G2 Success metric | At least one metric + baseline or a buildable measurement method | Only "easier to use", cannot define right/wrong | Convert to "define metric & baseline" task |
| G3 Data rights | Data obtainable; quality/coverage known; usage/export/third-party boundaries clear | Data unavailable, rights unclear, quality insufficient with no remedy | Convert to data due diligence; no PoC before done |
| G4 Evaluation path | Ground truth, human review, or acceptable task-success criterion | No one can judge right/wrong, or error cost unacceptable | Convert to "build 30–100 item eval set" task |
| G5 Operations & rollback | Owner, human fallback, rollback/stop plan after launch | No one maintains, cannot roll back on error | Convert to operations-plan design |
| G6 Compliance & security | Data classification, privacy/security/industry-regulatory review path done | Clearly violates regulation/contract, or cannot obtain needed authorization | Convert to legal/security review; no launch commitment before done |

`unknown` is not a fail, but it limits the conclusion level. Write each unknown as: **question, why it affects judgment, who answers by what date, how the conclusion changes after answering**.

## 3. Seven dimensions and scoring anchors

Use integers or decimals from 0–5:

- **0**: no information at all, or dimension not applicable and not explained.
- **1**: only wishes/concepts, no verifiable evidence.
- **3**: initial evidence, but key conditions unverified.
- **5**: sufficient evidence, executable, measurable, operable.

Do not habitually score 3. A 3 means "initial evidence but key conditions unverified", not "medium preference".

### 3.1 Business value & owner (weight 20)

| Score | Anchor |
|---|---|
| 1 | Only a "want to build AI" request; no owner, no pain-point evidence, no cost of not doing it |
| 3 | Clear owner and real case; pain exists, but scale/cost/metric still user-stated or unquantified |
| 5 | Owner has decision power; problem backed by data/cases; cost of not doing it clear; success metric tied to business outcome; clear non-goals |

### 3.2 Data readiness (weight 15)

| Score | Anchor |
|---|---|
| 1 | Don't know where data is or who may use it; or clearly unobtainable |
| 3 | Have samples/docs, but at least one of coverage/quality/update/permission/rights unverified |
| 5 | Representative sample obtainable; quality & coverage assessed; usage/export/third-party boundaries clear; update & versioning mechanism |

### 3.3 Technical fit (weight 15)

| Score | Anchor |
|---|---|
| 1 | Task doesn't need AI, or problem undefined, cannot judge tech route |
| 3 | Reasonable tech route, but integration/latency/failure mode/alternative unverified |
| 5 | Task boundary clear; simplest viable mode verified; integration path with existing systems clear; failure fallback; not relying on unverified capability assumptions |

### 3.4 Evaluation readiness (weight 15)

| Score | Anchor |
|---|---|
| 1 | No success definition; no one can judge output right/wrong |
| 3 | Have a metric, but no baseline, ground truth, or stable human-review process |
| 5 | Representative eval set/slice; baseline; clear pass criteria & disagreement handling; human review; regression & launch acceptance |

### 3.5 Cost & latency (weight 10)

| Score | Anchor |
|---|---|
| 1 | Don't know call volume, concurrency, latency tolerance, or budget |
| 3 | Rough magnitude, but unit economics/peak/cache-retry/human-review cost not computed |
| 5 | Magnitude & peak; unit cost/latency/failure-retry/human-fallback all computed; scale-down/degrade plan |

### 3.6 Risk & compliance (weight 15)

| Score | Anchor |
|---|---|
| 1 | High-risk scenario unidentified; or clearly cannot be done |
| 3 | Main risks identified, but grading/control/review path incomplete |
| 5 | Data/security/industry-regulatory classified; controls & retention; review/appeal/human-review; clear accountability boundary |

### 3.7 Operations & change (weight 10)

| Score | Anchor |
|---|---|
| 1 | No operations owner; no one considers process/role/training change |
| 3 | Have owner, but daily maintenance/human fallback/training/assessment/rollback not in place |
| 5 | Operations owner clear; process change/training/support/human fallback/rollback/continuous assessment all arranged |

## 4. Evidence levels and adjustment factors

Don't just score; also label how much evidence backs the score.

| Level | Meaning | Factor |
|---|---|---|
| `verified` | Backed by user docs/data or verifiable source, scope clear | 1.00 |
| `partial` | Partial evidence, but gaps in coverage/timeliness/scope | 0.85 |
| `assumed` | Assumption adopted to move forward, not yet verified | 0.55 |
| `unknown` | Essentially no information | 0.25 |

Adjusted-score formula:

```text
raw = Σ weight × (dimension_score / 5)
adjusted = Σ weight × (dimension_score / 5) × evidence_factor
```

The raw score says "how good if all these judgments hold"; the adjusted score says "how much we can trust it under current evidence". A large gap means you need more evidence, not more architecture discussion.

## 5. Cap rules

The script lowers the conclusion level per the rules below and lists the reasons in output. Human review may override, but must record the rationale and new evidence.

| Condition | Max level |
|---|---|
| G3 data-rights fail or G6 compliance-security fail | `hold` |
| Any other hard gate fail | `validate_first` |
| Hard-gate unknown ≥ 3 | `validate_first` |
| `verified` + `partial` weighted coverage < 50% | `validate_first` |
| adjusted ≥ 70 but coverage < 65% | `validate_first` |
| business value & owner ≤ 1 | `discovery_only` |
| data readiness ≤ 1 | `validate_first` |
| evaluation readiness ≤ 1 | `validate_first` |
| risk & compliance ≤ 1 | `validate_first` |
| adjusted ≥ 70 but hard-gate unknown > 1 | `validate_first` |

Notes:

- Coverage is computed by dimension weight, not by count of dimensions.
- Capping only lowers the level, it does not change the score; show both the score and cap reasons in the report.
- If a hard gate fails but business value is very high, the correct conclusion is "fix the fail first", not "high score grants an exception".

## 6. Conclusion levels

| Level | Adjusted score | Meaning | Next step |
|---|---|---|---|
| `proceed_to_poc` Proceed to PoC | ≥70, coverage ≥65%, hard-gate unknown ≤1 | Value, data, evaluation, operations basically formed, risk controllable | Write a one-page PoC plan; lock scope, baseline, acceptance, rollback |
| `validate_first` Validate first | 55–69 | Direction may hold, but key assumptions/evidence insufficient | Add data, eval set, user tests, or compliance review within 2–4 weeks |
| `discovery_only` Discovery only | 35–54 | Value and conditions not yet formed | Do scenario retrospective, requirement layering, feasibility interviews; no production code |
| `hold` Hold | <35 | Conditions don't hold or there is a hard blocker | Resolve the blocker, or explicitly not do it; don't bypass with "build a demo first" |

Score boundaries are not natural laws; they are a team-agreed communication tool. If the adjusted score conflicts with hard gates / human judgment, the gates and human judgment win, with an explanation why.

## 7. Questions human review must answer

1. Which dimension is most uncertain? Could it flip the conclusion from "doable" to "not doable"?
2. Are there counter-examples/failure samples masked by the average?
3. If the PoC fails, is the loss tolerable? Can we get a clear signal within 2–6 weeks?
4. Is there a simpler non-AI option? Why is it insufficient?
5. Who bears post-launch operations and incident responsibility?
6. If a key assumption is wrong, what is the exit cost?
7. Is there a case of "technically possible but shouldn't be done business-wise"?

## 8. Common misjudgments

- **Tech score masks no owner**: no matter how good the model, if no one uses or maintains it, it shouldn't enter PoC.
- **Treating unknown as a 3**: unknown is not "medium", it is unknown; it should trigger a verification task.
- **Using vendor benchmark as your own feasibility**: vendor data only shows "under their test conditions"; you must evaluate with your own samples.
- **Demo success = launchable**: a demo only proves "one time it worked", not failure rate, long tail, cost, or operational viability.
- **Average masks the long tail**: a high-probability/low-probability error may matter more than average accuracy.
- **Build Agent before finding a scenario**: start from the simplest mode; complexity needs evidence.
- **Ignoring human-fallback cost**: human review is not free; count it in unit cost and latency.
- **Treating PoC as production**: a PoC's exit criterion is "whether it's worth continuing", not "whether it can be demoed".

## 9. Scoring record template

```yaml
project: <name>
as_of: <YYYY-MM-DD>
gates:
  business_owner: pass | fail | unknown
  success_metric_baseline: pass | fail | unknown
  data_access_rights: pass | fail | unknown
  evaluation_path: pass | fail | unknown
  operational_owner: pass | fail | unknown
  compliance_review: pass | fail | unknown
dimensions:
  value_and_owner:      { score: 0-5, evidence: verified|partial|assumed|unknown, note: "<basis>" }
  data_readiness:       { score: 0-5, evidence: verified|partial|assumed|unknown, note: "<basis>" }
  technical_fit:        { score: 0-5, evidence: verified|partial|assumed|unknown, note: "<basis>" }
  evaluation_readiness: { score: 0-5, evidence: verified|partial|assumed|unknown, note: "<basis>" }
  cost_and_latency:     { score: 0-5, evidence: verified|partial|assumed|unknown, note: "<basis>" }
  risk_and_compliance:  { score: 0-5, evidence: verified|partial|assumed|unknown, note: "<basis>" }
  operability_and_change:{ score: 0-5, evidence: verified|partial|assumed|unknown, note: "<basis>" }
```

Corresponding script: `scripts/score_feasibility.py`. Example: `assets/feasibility-input.example.json`.
