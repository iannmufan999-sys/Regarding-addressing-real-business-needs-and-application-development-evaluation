# Reference Index

Load on demand; do not read everything into context at once. Read the routing table in `SKILL.md` first, then open only the file needed for the current task.

| File | When to load | Key content |
|---|---|---|
| `discovery-protocol.md` | Opening diagnosis, requirement interviews, scenario retrospective | Six minimum facts, five paths, probing library, fact ledger, anti-patterns |
| `feasibility-rubric.md` | Scoring / judging feasibility | 6 hard gates, 7-dimension 0–5 anchors, evidence factors, cap rules, misjudgment cases |
| `evidence-verification.md` | Citing industry data / regulations / technical capability / prices | Source grading, recency windows, five-step verification, Claim Ledger, official entry points, citation format |
| `solution-patterns.md` | Choosing RAG / Agent / fine-tuning / full-stack | Mode matrix, RAG/Agent/fine-tuning checklists, evaluation, guardrails, cost, anti-patterns |
| `delivery-playbook.md` | Planning PoC / pilot / launch / handover | Phases & exit criteria, PoC plan, acceptance, observability, risk, handover |
| `output-templates.md` | Writing reports / review materials | Diagnosis notes, feasibility memo, PoC plan, evidence appendix, one-pager |

## Minimal loading suggestions

- **Diagnosis only**: `discovery-protocol.md`.
- **Feasibility conclusion**: `discovery-protocol.md` + `feasibility-rubric.md`, then run `score_feasibility.py`.
- **Citing industry data**: `evidence-verification.md`, then run `audit_evidence.py`.
- **Choosing a tech route**: `solution-patterns.md`.
- **Scheduling delivery**: `delivery-playbook.md` + `output-templates.md`.
- **Producing a report**: `output-templates.md` + the relevant evidence appendix.

## Reading order

1. Confirm the fact ledger and hard gates first; do not read architecture details while facts are unclear.
2. Then read the references relevant to the current decision; do not treat every checklist as a mandatory questionnaire.
3. Finally organize conclusions with `output-templates.md`, keeping unknowns, counter-examples, and evidence sources prominent.
