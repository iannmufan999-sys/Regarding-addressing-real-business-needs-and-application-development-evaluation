# Scenario Diagnosis & Requirement Mining Protocol

This file covers the first half of "diagnose first, then advise": restoring the user's business reality into verifiable scenarios, requirements, and gaps. Every method serves one constraint: **do not fill in business conditions the user did not provide.**

## 1. Six minimum facts before diagnosis

Before proposing any solution, confirm at least these six items. If one is missing, mark it `[to-confirm]`; do not fill it with common sense.

| # | Fact | Depth required |
|---|---|---|
| F1 | Business goal | Which business outcome improves? Who benefits? What is the cost of not doing it? |
| F2 | Roles & decision-makers | Who executes, who reviews, who decides, who bears the failure? |
| F3 | Trigger & process | What event starts the process? What are the steps, systems, and handoffs? |
| F4 | Inputs & outputs | What format/source/frequency are inputs? Who receives outputs, for what action? |
| F5 | Scale & constraints | How many tickets/documents/users per day/month? Latency/budget/staffing boundaries? |
| F6 | Data & compliance | Where is the data, who may use it, can it leave the domain, any sensitive/regulated data? |

If the user can only give partial facts, do a "conditional diagnosis" first: state "if A holds, advise X; if B does not hold, X does not hold." Do not write the conditional as a definitive conclusion.

## 2. Scenario retrospective: replay, don't invent a story

The scenario retrospective (scenario replay) uses only the roles, systems, process, and data the user already provided. The goal is to expose breakpoints, exceptions, and cost of failure — not to produce a story that looks complete.

### 2.1 Pick a real slice

Ask the user to pick a **recent, desensitizable, representative** case. Prefer "frequent and annoying" over "most extreme." If the user has no real case, only a hypothetical walkthrough is allowed, and the title must state "hypothetical walkthrough, not a user fact."

### 2.2 Replay along the timeline

For each step record:

| Field | Question |
|---|---|
| Trigger | What event/time/signal starts this step? |
| Role | Who executes? Who reviews? Who can stop it? |
| What is seen | What actually shows on screen/document/message/system? |
| Judgment | What decision is needed? On what rule/experience? |
| Action | What was clicked, looked up, asked, copied where? |
| System | Which existing systems are involved? Manual or automatic interface? |
| Output | What is produced? Handed to whom? Used how next? |
| Failure | What if it errors/timeouts/refuses/can't be found? Who catches it? |
| Cost | Rework, waiting, complaints, compliance risk, opportunity cost? |

### 2.3 Cover five paths

Walk through at least:

1. **High-frequency normal path**: how it is usually completed.
2. **Peak/batch path**: where it breaks under high volume or tight deadlines.
3. **Exception path**: policy change, missing fields, cross-department, special customers.
4. **Failure path**: model answers wrong, retrieval misses, tool call fails, network/permission fault.
5. **Human fallback path**: who takes over, what context they see, how to roll back.

### 2.4 Stress-test, don't pad facts

You may stress-test with "what if…", but every "if" must be tagged `[assumption]` with its verification method. For example:

- `[assumption]` If policy updates monthly, retrieval must support incremental updates and version tracing; verify by obtaining the last three policy-change records.
- `[assumption]` If frontline issues several requests per second at peak, latency requirements may exceed offline scenarios; verify with real peak-period request logs.

Do not write "usually the business would…" or "generally enterprises…" in place of user facts.

### 2.5 Retrospective outputs

- A flow table "trigger → action → system → output → failure → cost".
- A "breakpoint/gap" list: each breakpoint tied to a fact ID or `[to-confirm]`.
- A "failure mode" list: error type, how discovered, current fallback, acceptability.
- A "assumptions to verify" list: assumption, impact, verification method, owner.

## 3. From surface request to real need

Use a four-layer structure; do not jump from "what the user said they want" straight to "so let's build it."

### 3.1 Four-layer breakdown

| Layer | Question to answer | Example (structural example, not industry fact) |
|---|---|---|
| Surface request | What did the user literally ask for? | "Build a customer-service Agent." |
| Real need | Who, under what conditions, needs what result? | "<role> needs <result> at <trigger>, because <evidence>." |
| Business outcome | Cost of not doing it / metric that improves if done well? | "Reduce <rework/waiting/errors>, improve <measurable metric>." |
| Constraints & non-goals | What must not be done, what is deferred, who decides? | "<compliance boundary>; phase 1 excludes <scope>." |

### 3.2 Requirement evidence chain

Every "real need" needs at least one of:

- A real case, ticket, log, document, or screenshot (desensitized) provided by the user.
- A frequency/scale/duration/error-rate the user explicitly stated (label "user-stated").
- A verifiable public source (only for industry/regulatory/technical capability, not to replace the user's internal facts).
- Direct interview notes of frontline/reviewer/manager (note role and date).

A pain point without evidence is an `[assumption]`, not a project justification.

### 3.3 Existing alternatives

Always ask: how is the work done today without this AI application?

- Manual rules/templates/search/outsourcing/legacy system/doing nothing.
- Concrete cost of the current approach: time, staffing, errors, waiting, opportunity loss.
- Why the current approach is insufficient: capability, capacity, consistency, timeliness, experience, compliance.
- Why do it now: trigger event, budget cycle, strategy, competition, regulatory change.

If the current approach "barely works" at low cost, AI may not be the right answer; be willing to conclude "don't invest / optimize the process first."

## 4. Probing library

Ask at most 3 questions per round that would change the conclusion. Choose by priority; do not dump a full questionnaire at once.

### 4.1 Business & value

- How often does this process happen per month? Roughly how long each time? Who is waiting?
- If we do nothing today, what is the worst that happens? Any quantifiable rework/complaints/churn?
- Which metric must improve for this to count as success? What is it now? Who watches it?
- Who decides? Where do budget/staffing come from? Who bears the failure?
- What is phase 1 absolutely NOT doing, and why?

### 4.2 Process & roles

- Can you walk through one recent real case on the timeline?
- Which step most depends on individual experience? How long for a newcomer to learn?
- Which steps require human confirmation? Who has permission?
- Who is called on exceptions? How do they judge? Is there an escalation path?
- If the AI answers wrong, who discovers it, and how long does it take?

### 4.3 Data & knowledge

- Where is the knowledge/data? Who maintains it? How often is it updated?
- Are there permission differences (different roles see different content)?
- Can the data leave the domain / go to cloud / go to a third party? On what basis?
- Are there labels/ground truth/historical results? What is their quality?
- Is the sample size enough to cover the long tail and exceptions?

### 4.4 Evaluation & acceptance

- What counts as "answered correctly"? Who defines it? How are disagreements handled?
- Is there a historical baseline (manual/legacy system)?
- What error rate is acceptable? Is the cost of errors symmetric?
- What tests must pass before launch? Who signs off?
- How is it monitored in production? How is it rolled back on problems?

### 4.5 Operations & change

- After launch, who owns daily operations, data updates, model/prompt versions?
- Why would frontline use it? What if they don't? What training/incentive?
- Which processes/roles/assessments need to change?
- If something breaks, who is accountable? Is there a human fallback capacity?
- How is it evaluated after 6 months to continue/scale/stop?

### 4.6 Compliance & security

- Does it involve personal information, sensitive personal information, minors, medical/financial/legal advice?
- Are there industry licenses, filings, audits, retention requirements?
- Is there cross-border/data-export/third-party processing?
- Is explainability, appeal, human review required?
- Who owns the security baseline (accounts, permissions, keys, logs, vendors)?

## 5. Fact ledger

Maintain a table each turn. One fact per row; do not merge multiple judgments.

| ID | Statement | Tag | Source / verification | Impact |
|---|---|---|---|---|
| F1 | Current process requires manual policy-clause checking | `[confirmed]` | User interview + ticket screenshot (desensitized) | Supports "knowledge retrieval" need |
| U1 | Policy update frequency | `[to-confirm]` | Need last 3 change records | Determines need for incremental indexing |
| A1 | Frontline willing to ask in natural language | `[assumption]` | 5-person usability test | If false, UI must change |
| R1 | Phase 1 only retrieval Q&A, no auto-refund | `[suggestion]` | Based on risk boundary | Narrows PoC scope |

Rules:

- `[confirmed]` must point to a source; user interview counts as a source but note "user-stated".
- `[to-confirm]` must be written as an answerable question, not "data situation pending".
- `[assumption]` must state the verification method and "what if wrong".
- `[suggestion]` must not appear in "current state / facts" sections.

## 6. Suggested diagnosis agenda (45–60 min)

1. **Goal & boundary (5 min)**: what to decide today? What not to discuss?
2. **Real-case replay (15 min)**: one normal path + one failure path on the timeline.
3. **Roles & decisions (10 min)**: who executes, who reviews, who decides, who bears failure.
4. **Data & evaluation (10 min)**: where is the data, where is ground truth, what is "correct".
5. **Constraints & compliance (5 min)**: what must not be done, what must be retained/audited.
6. **Gaps & next steps (10 min)**: confirm fact ledger, assumptions to verify, owner and date.

Send the diagnosis notes within 24 hours; do not write unconfirmed facts as conclusions.

## 7. Common anti-patterns

- **Solution jumping**: user says "want an Agent", immediately draw a multi-agent architecture. Ask first whether the task needs dynamic decision-making.
- **Leading questions**: "don't you think retrieval is slow?" induces answers. Ask "how long did the last handling take? how do you know it was slow?"
- **Invented persona**: invent a "typical CSR" to represent all users. Use only roles the user confirmed.
- **Average trap**: use averages to hide the long tail/exceptions; ask for distribution, worst cases, failure samples.
- **Demo evidence**: treat one successful demo as feasibility evidence; require repeated samples, failure rate, and baseline.
- **Questionnaire dump**: send 30 questions at once, forcing generic answers. Ask only the 3 most conclusion-affecting each round.
- **False precision**: compute ROI, accuracy uplift, or labor saved when the user gave no data. Either get the data, or give a ranged assumption and label it.

## 8. Minimum diagnosis output

- Scenario boundary and fact ledger.
- One normal-path and one failure-path retrospective.
- Surface request / real need / business outcome / non-goal.
- Hard-gate status (pass/fail/unknown) and assumptions to verify.
- Next steps: who, by what date, what evidence to add.

Full report templates in `output-templates.md`; feasibility scoring in `feasibility-rubric.md`.
