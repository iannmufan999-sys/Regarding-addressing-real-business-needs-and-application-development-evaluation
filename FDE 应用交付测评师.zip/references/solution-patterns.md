# Solution Patterns & AI Full-Stack Delivery Checklist

This file helps choose the "simplest sufficient" technical pattern and breaks RAG, Agent, fine-tuning, and full-stack engineering into verifiable check items. **Pattern choice is a design judgment, not industry statistics; all tool candidates must come from the user's current stack or an explicitly permitted scope.**

## 1. Selection principles

1. **Ask about the task before the model.** Does the task need natural-language understanding? External knowledge? Dynamic action? Long-term memory?
2. **Simplest pattern first.** If rules/templates/search/fixed-flow solve it, don't bring in an Agent; if one retrieval solves it, don't do multi-step planning.
3. **Every added complexity needs evidence.** Why RAG/Agent/fine-tuning? Show with failure cases, baselines, evaluation — not "more advanced".
4. **Rollback-able, observable, evaluable.** A plan without failure fallback and evaluation is not a deliverable plan.
5. **Tools start from the current state.** The user's existing models, cloud, databases, frameworks come first; new tools must state alternatives, lock-in risk, exit cost.
6. **Narrow PoC first.** One user group, one workflow, one measurable goal; don't build a "platform" in phase 1.

## 2. Pattern selection matrix

| Pattern | Fits | Doesn't fit | Minimum verification |
|---|---|---|---|
| Prompt + fixed flow | Clear task boundary, stable output format, enumerable rules | Frequently changing knowledge, multi-step tools, strong personalization | Small-sample output quality + failure fallback |
| RAG (retrieval-augmented) | Knowledge-dense, needs citation/traceability, fast-updating knowledge, answer in documents | Mainly reasoning/computation/action; poor document quality; unresolved complex permissions | Retrieval hit rate + citation correctness + refusal |
| Tool calling (single/short steps) | Need to query systems, compute, send requests, but path relatively fixed | Unclear tool permissions, non-rollbackable failures, high-risk actions | Tool success rate + permission/confirmation + failure recovery |
| Agent (multi-step planning) | Unfixed path, needs dynamic tool selection, decomposable, verifiable, rollback-able | Simple tasks, high error cost, not observable, no human fallback | Task success rate + steps/cost + privilege/loop tests |
| Fine-tuning / distillation | Stable style/format/domain behavior, sufficient high-quality labels, clear baseline | Strong knowledge timeliness need, little data, no prior baseline, unclear compliance | Compare to baseline + hold-out set + regression |
| Hybrid | Combination of the above, each layer with clear responsibility | Stacking components just for "complete architecture" | End-to-end eval + layered attribution |

> Rule of thumb: **knowledge problems → RAG first; process problems → workflow first; action problems → tools + permission first; behavior/style problems → consider fine-tuning.** This is a design heuristic, not industry data.

## 3. RAG checklist

### 3.1 Corpus & permissions

- Corpus list: source, format, owner, update frequency, version, language.
- Permissions: do different roles see different documents? Does the retrieval layer inherit permissions?
- Quality: how to handle duplicates, staleness, conflicts, scans, tables, attachments?
- Rights: can it be used for retrieval/training/display? Any third-party copyright/confidentiality limits?
- Deletion: when a document is deleted/withdrawn, how do index and cache sync?

### 3.2 Chunking & indexing

- Does the chunk unit match the question (paragraph/clause/table/FAQ)?
- Are metadata like title, section, effective date, scope preserved?
- Do tables/images/attachments need separate parsing? How to degrade on parse failure?
- Is there incremental update and version tracing? How to avoid stale-version answers?
- Do queries need rewriting/multilingual/synonym handling?

### 3.3 Retrieval & generation

- Retrieval: keyword, vector, hybrid, rerank; filter by permission/time/region?
- Hits: is Top-k enough? Are key clauses cut apart?
- Generation: forced citation? Can citation locate the original? Refuse when no basis?
- Conflict: when documents contradict, how presented? Show the conflict rather than fabricate one answer?
- Long tail: negative questions, multi-hop, tabular, time-sensitive questions — how tested?

### 3.4 RAG evaluation

Test at least:

- **Retrieval layer**: Recall@k, MRR, key-clause hit rate, permission-filter correctness.
- **Generation layer**: answer correctness, citation correctness, groundedness (is there original support), refusal rate, hallucination rate.
- **Task layer**: manual handling time, first-resolution rate, transfer-to-human rate, user satisfaction.
- **Slices**: bucket by document type, question type, role, timeliness, long tail; don't just look at the total.

No ground truth yet? First manually label 30–100 representative Q&As, define "correct/partially-correct/wrong/should-refuse", then talk automation.

## 4. Agent checklist

### 4.1 When is an Agent actually needed

Consider only when all hold:

- Task path unfixed, needs to choose the next step based on intermediate results.
- Multiple callable tools/systems with clear boundaries.
- Failures detectable, rollback-able, or with low-cost human fallback.
- Acceptable task success rate and cost ceiling.
- Observability: what was done each step, why, at what cost.

When not met, fixed workflow + single-step tool calling is usually more stable, cheaper, better tested.

### 4.2 Tools & permissions

- Tool list: name, input/output, permission, side effects, idempotency, timeout, rate limit.
- Least privilege: only the permission needed to complete the task; separate read/write; second confirmation for sensitive actions.
- High-risk actions: refund, transfer, delete, send, change config, external commitment — must have human confirmation/approval.
- Sandbox: is code execution, browser, file system isolated? Can it reach intranet/keys?
- Audit: every tool call leaves a trace: who, when, what params, result, human-confirmed?

### 4.3 Planning & state

- Is task decomposition verifiable? Does each step have success/failure signal?
- Are max steps, max cost, max duration limited?
- How to detect and terminate loops/repeated calls?
- How to recover on mid-way failure? Support breakpoint/retry/rollback?
- Memory: cross-session memory needed? How are write/read/delete/contamination managed?

### 4.4 Agent evaluation

- Task success rate (end-to-end, not single-step).
- Average steps, tool calls, token/cost, latency.
- Privilege-escalation rate, dangerous-action interception rate, human-confirmation rate.
- Loop/freeze rate, failure-recovery rate.
- Adversarial testing: prompt injection, tool misdirection, malicious documents, permission bypass.
- Buckets: simple/complex, single-tool/multi-tool, normal/abnormal.

## 5. Fine-tuning / distillation checklist

- Is the task stable? Are input/output distributions definable?
- Sufficient, clearly-licensed, quality-controllable labeled data?
- Is a prompt/RAG baseline already established? What is the gain of fine-tuning over baseline?
- Is the hold-out set independent? Does it cover long tail/adversarial samples?
- Does it cause general-capability regression/forgetting? Need routing/hybrid?
- Update frequency: after knowledge/behavior change, what is the retrain/rollback cost?
- Compliance: training-data rights, personal information, output responsibility.

Fine-tuning is not the first choice for "pouring knowledge in"; knowledge-timeliness problems → RAG first. Fine-tuning suits stable behavior/format/domain decision patterns, but must be compared to a baseline.

## 6. AI full-stack blueprint (vendor-neutral)

| Layer | Problem to solve | Minimum deliverable |
|---|---|---|
| Experience layer | Who uses it, on what UI, how to give feedback/appeal | Key-flow prototype, error/refusal/transfer-to-human states |
| API / orchestration | Request routing, session, retry, timeout, rate limit | Interface contract, error codes, idempotency/retry strategy |
| Retrieval / knowledge | Corpus, index, permission, update, citation | Data card, index version, permission model, update job |
| Tool / action | Query systems, write ops, permission, confirmation | Tool list, least privilege, audit, rollback |
| Model layer | Model selection, prompt/version, degradation | Model card, prompt version, routing/degradation strategy |
| Evaluation layer | Ground truth, offline/online, regression | Eval set, scoring script, human review, report |
| Observability layer | Quality, cost, latency, security | Trace, metrics, alerts, log desensitization |
| Data / security layer | Classification, desensitization, keys, compliance | Data-flow diagram, DPIA/security review, retention/deletion policy |
| Delivery / ops layer | Deployment, version, on-call, rollback | Runbook, release process, on-call roster, kill switch |

## 7. Evaluation design

### 7.1 Offline evaluation

- Eval-set sources: real historical cases, manual construction, adversarial samples; avoid only model-generated questions.
- Scale: start with 30–100 usable, then expand; cover normal/long-tail/refusal/adversarial.
- Labeling: dual labeling + disagreement arbitration; record labeling guide and version.
- Metrics: task success, factual correctness, citation correctness, format compliance, refusal correctness, safety.
- Baseline: human, legacy system, simplest prompt; no baseline means no "improvement".

### 7.2 Boundaries of LLM-as-judge

- Usable, but must be calibrated against human labels; don't treat judge score as the only ground truth.
- Fix judge prompt/model/version; spot-check consistency.
- Keep human review for high-risk/boundary samples.
- Watch judge bias: length, format, confident tone, same-model-family preference.

### 7.3 Online evaluation

- Canary/shadow mode: first don't affect real actions, compare AI vs human.
- Task metrics: first-resolution rate, transfer-to-human rate, handling time, rework rate.
- Quality metrics: error rate, missing citations, refusal rate, user feedback.
- Cost/latency: P50/P95, per-task cost, retry cost.
- Safety: privilege escalation, sensitive info, prompt injection, abnormal tool calls.

## 8. Guardrails & security

- Input: length/format limits, prompt-injection detection, file/URL allowlist, sensitive-info detection.
- Output: citation requirement, refusal strategy, sensitive-content filtering, format validation.
- Tools: least privilege, second confirmation, rate limit, sandbox, idempotency, audit.
- Data: classification, desensitization, encryption, retention/deletion, cross-border limits.
- Human-AI boundary: high-risk actions must have human confirmation; AI doesn't replace professional judgment.
- Operations: kill switch, rollback, incident response, vendor-failure degradation.

## 9. Cost & latency

Don't judge with "probably cheap". At least estimate:

- Per-task input/output tokens, retrieval count, tool-call count, retry count.
- Peak concurrency, P95 latency, human-review cost, failure-retry cost.
- Index/storage/embedding/rerank/log/evaluation cost.
- How much caching, batching, model routing, degradation save.
- Bottlenecks when scaling 10x/100x.

Do small-sample real measurement first, then extrapolate from measured values; don't multiply vendor unit price by user count directly.

## 10. Build / buy / partner

| Option | Fits | Risk |
|---|---|---|
| Build | Core differentiation, complex data/permissions, deep integration needed | Team capability, maintenance cost, time-to-launch |
| Buy | Generic capability, fast launch, replaceable vendor | Lock-in, data export, price, SLA, exit cost |
| Partner / outsource | Lack capability, short-term project | Knowledge transfer, code/data ownership, follow-up maintenance |
| Hybrid | Core built, periphery bought | Interface/responsibility boundary, observability |

When deciding, state clearly: total cost of ownership, exit cost, data ownership, SLA, vendor-failure contingency.

## 11. Common anti-patterns

- **Agent omnipotence**: every task gets multi-agent, becoming untestable/uncontrollable.
- **RAG without evaluation**: only look at a few demo Q&As, don't test retrieval hit, citation, refusal.
- **Fine-tune before baseline**: collect data to train before establishing a prompt/RAG baseline.
- **Demo-driven**: one successful demo triggers a project, ignoring failure rate and long tail.
- **Architecture stacking**: vector DB, agent framework, workflow engine all at once, no layer with clear responsibility.
- **Ignoring permissions**: retrieval layer doesn't inherit document permissions, causing privilege-escalation leaks.
- **No human fallback**: process freezes when the model fails.
- **Vendor benchmark as acceptance**: don't evaluate with your own data.
- **Ignoring operations**: after launch no one updates knowledge, watches metrics, handles incidents.

## 12. Solution decision record template

```markdown
## Decision: <which pattern/tool to choose>
- Problem to solve: <one sentence>
- Why simplest mode is insufficient: <evidence/failure case>
- Candidates: <A/B/C, including current-state tools>
- Reason for choice: <capability/cost/latency/risk/team>
- Reason against others: <why alternatives don't fit>
- Key assumptions: <to verify>
- Exit / rollback: <how to stop, how to switch>
- Evaluation & acceptance: <metric/baseline/method>
- Decision-maker / date: <...>
```
