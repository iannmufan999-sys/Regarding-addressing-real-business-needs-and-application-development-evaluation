# Evidence Verification & Industry-Data Usage Rules

This file solves one core problem: **how to turn "industry experience/data" into verifiable, citable, falsifiable evidence — not professional-sounding fabrication.**

## 1. Three bottom lines

1. **No source = not a fact.** You may write "unverified assumption", but you must not write "according to an industry report", "widely believed", or "best practice shows" without a concrete source.
2. **The source must be openable, locatable, and scope-checkable.** Only a homepage, search page, secondary paraphrase, screenshot, or chat log does not count as a verifiable source.
3. **A source's conclusion must not exceed its scope.** Data differing in region, industry, company size, time, sample, or test conditions cannot be directly merged into your business conclusion.

## 2. Source grading

| Tier | Source type | Usable for | Caveats |
|---|---|---|---|
| A | Regulators, government statistics, court/law-enforcement notices, official gazettes | Regulations, policies, penalties, official statistics | Check in-force version, scope, publication date |
| A | Standards bodies (ISO/IEC, national standardization agencies, TC260, etc.) | Standards, terms, control requirements | Standards may be paid; distinguish published/draft/withdrawn |
| A | Official product docs, model cards, system cards, official pricing pages | Product capability, limits, price, quota | Only proves that vendor's claim for that version; price/capability change |
| B | Peer-reviewed papers, DOI-locatable academic publications | Methods, experimental results, technical boundaries | Check sample, baseline, reproduction conditions; label preprints separately |
| B | Primary industry reports disclosing method, sample, scope | Industry trends, adoption, cost ranges | Check sponsor, sample bias, vendor sponsorship |
| C | Vendor blogs, whitepapers, sales materials | Product claims, case leads | Must be tagged "vendor statement"; not independent industry evidence |
| D | Media, wikis, SEO rankings, "reports" without methodology | Leads | Not a factual basis; must trace back to A/B sources |
| — | Facts/files/interviews the user provided | User's internal facts | Tag "user-stated"; do not generalize to industry data |
| — | Practitioner experience | Assumption, interview lead | Tag "experience judgment / to be verified"; not a statistic |

> "Official" is not the same as "correct". Official sources may also have scope limits, lag, or scope changes. Keep the original qualifiers when citing; don't just lift the conclusion.

## 3. Recency windows

These are default strategies, not regulations. If a decision needs older data, you must explain why it still applies.

| Data type | Default freshness | Handling |
|---|---|---|
| Technical capability, model/product features, price, quota | Within 12 months | Reopen the official page if exceeded; flag "may have changed" |
| Industry data, adoption, market size, cost ranges | Within 24 months | Find an updated version if exceeded; otherwise downgrade to "historical reference" |
| Regulations, regulatory guidance, standards | Current in-force version | Record publish/update/effective dates; check for revision/withdrawal |
| Vendor claims, cases | Within 18 months | Tag "vendor statement"; find independent source for cross-validation |
| Academic research | Depends on field | Prefer last 5 years; classic methods may be exceptions with reason |

"Recent" doesn't mean "newest is best": pick the version **relevant to the current decision and representative of current conditions**. A pricing page may change monthly; a regulation may be unchanged for ten years.

## 4. Five-step verification method

### Step 1: Define the decision

Write first: "which judgment is this evidence meant to support?"

- Is it "this scenario is worth doing", "this technology is achievable", or "this price is affordable"?
- If the evidence didn't exist, how would the conclusion change?
- Do you need an industry mean, a range, a failure rate, or a single case?

Without a decision question, don't search "AI industry trends" aimlessly.

### Step 2: Find primary sources

Add qualifiers when searching:

- `site:gov.cn`, `site:gov`, `site:europa.eu`, `site:iso.org`, `site:nist.gov`
- `filetype:pdf` + institution name + year
- English: `official statistics`, `regulator`, `standard`, `annual report`, `methodology`
- Chinese: `官方` (official), `统计公报` (statistical bulletin), `白皮书` (whitepaper — note it may also be vendor), `征求意见稿` (draft for comment), `生效` (in force)

Start with Tier A; if none, go to Tier B; C/D are only leads.

### Step 3: Open the original, not just the abstract

You must confirm:

- Page title, publisher, publish/update date.
- Data scope: region, industry, company size, sample size, statistical period, definitions.
- Whether it is the original, a reprint, an abstract, or an AI-generated "report interpretation".
- Whether there is a stakeholder funding/sponsorship.
- Whether chart footnotes, appendices, and method notes support the body conclusion.

Search-result snippets may be outdated or rewritten; **open the original page before citing**.

### Step 4: Record metadata

For each claim, record at least:

```text
Publisher | Title | Publish/Update date | URL | Access date | Scope (region/industry/time/sample) | Key original sentence
```

For regulations, also add: effective date, applicable objects, transition period, revision history.

For papers, also add: DOI, sample, baseline, experimental conditions, limitations.

### Step 5: Cross-validate and downgrade

- At least two independent sources support the same key conclusion (a reprint by the same institution doesn't count as independent).
- Vendor statement + independent test/regulatory record beats a vendor's unilateral claim.
- If only a single source, tag `partial`, don't write "industry consensus".
- If sources conflict, keep the conflict and explain the difference may come from scope/time/sample.
- If not verifiable, tag `unverified` and move it from the facts section to "assumptions to verify".

## 5. Claim Ledger

Each claim entering the report gets one row. The script `scripts/audit_evidence.py` checks structure, not content truth.

```json
{
  "as_of": "2026-10-28",
  "claims": [
    {
      "id": "C1",
      "claim": "<one-sentence claim, keep qualifiers>",
      "claim_type": "industry_data | technical_capability | regulation | vendor_claim | user_fact | practitioner_experience",
      "source": {
        "title": "<page/report title>",
        "publisher": "<publishing body>",
        "url": "https://<specific page>",
        "source_type": "official | standard | peer_reviewed | vendor | media | blog | other | user_input | practitioner",
        "published": "YYYY-MM-DD",
        "updated": "YYYY-MM-DD",
        "accessed": "YYYY-MM-DD",
        "reference": "<required for user_input/practitioner: interview date, role, file path>"
      },
      "scope": "<region/industry/company size/time/sample; for regulation, applicable objects>",
      "status": "verified | partial | unverified",
      "notes": "<conflict, limitation, why still applicable>"
    }
  ]
}
```

Status definitions:

- `verified`: source openable, scope clear, directly corresponds to the claim, within recency window.
- `partial`: source exists, but gaps in timeliness/scope/independence/coverage.
- `unverified`: no verifiable source, or only leads; must not be used as fact.

Type rules:

- `industry_data`: must be Tier A/B; must have scope; vendor/media/blog alone cannot support it.
- `regulation`: must be official/standard source; must have applicable objects and effective info; not a substitute for legal advice.
- `technical_capability`: official docs/papers/standards preferred; vendor docs only prove that vendor's product, tagged "vendor statement".
- `vendor_claim`: must tag the vendor source; must not be written as independent fact; price/performance must note the date.
- `user_fact`: provided by user; tag "user-stated"; not generalized to industry data.
- `practitioner_experience`: experience judgment; only as assumption/lead; must not be written as a statistical conclusion.

## 6. Citation format

Inline citation:

```text
(Publisher, Title, Publish/Update date, URL, Access date; Scope: …)
```

Example (structural example, no specific data):

```text
(<regulator>. <guidance name>. <publish date>. <URL> (accessed <date>); applies to <region/industry/object>.)
```

Report appendix table:

| ID | Claim | Type | Source | Date | Scope | Status |
|---|---|---|---|---|---|---|
| C1 | <claim> | industry_data | <publisher/title/URL> | <publish/update> | <region/industry/sample> | verified/partial/unverified |

Rules:

- Don't use "according to an industry report" instead of the title and publisher.
- Don't use search-page URLs, short links, or screenshots instead of the original URL.
- Don't fabricate DOIs, page numbers, report names, authors, or publish dates.
- Keep qualifiers like "under conditions…", "sample was…", "the institution estimates…" when paraphrasing.
- Label your own derivations separately as "derivation based on C1/C2" with formula and assumptions.

## 7. How to use vendor statements

Vendor materials can answer:

- What the product claims it can do, its limits, price/quota.
- Interfaces, parameters, deprecation policy in official docs.

They cannot answer:

- "Industry-wide adoption", "market leader", "average accuracy", "customer ROI".
- "Our scenario will achieve the same effect".

Usage rules:

1. Tag "vendor statement / vendor doc"; don't write as independent fact.
2. Record date and version; price/features change easily.
3. Find independent tests, customer cases, regulatory records, or your own small-sample test for cross-validation.
4. Vendor benchmarks must show test set, baseline, prompt, scoring method; cannot be directly migrated to your data.

## 8. Common industry-data traps

- **Definition drift**: the same metric defined differently across reports (active users, accuracy, success rate).
- **Sample bias**: only surveys top enterprises/paid customers/English-speaking markets, then generalizes to all enterprises.
- **Survivorship bias**: only success cases, no failed projects reported.
- **Scope mixing**: merges global market, a country's market, an industry, and a company-size segment.
- **Time mismatch**: uses 2023 model capability/price to judge a 2026 solution.
- **Self-report bias**: adoption/ROI from vendor-commissioned surveys or user self-reports.
- **AI-generated reports**: look like reports but have no author, method, or data source; treat as Tier D.
- **Secondary-paraphrase distortion**: media writes "improved X%" under specific conditions as "generally improved X%".
- **Benchmark contamination**: test set enters training data, or evaluation method is not reproducible.
- **Exchange-rate/tax/labor-cost differences**: cross-country cost data cannot be applied directly.

## 9. Official source entry points (entry points, not citations)

These are common official entry points. **You must open the specific page and record title, date, URL, and scope before citing; this table itself is not evidence.** Some government sites return 403/CAPTCHA to automated crawlers; that doesn't mean the source is invalid, but you still need to open and verify it manually in a browser.

| Topic | Entry point |
|---|---|
| China cyberspace/data/algorithm governance | https://www.cac.gov.cn/ |
| China industry/IT policy | https://www.miit.gov.cn/ |
| China national standards (full text) | https://openstd.samr.gov.cn/ |
| National standards public service platform | https://std.samr.gov.cn/ |
| National cybersecurity standardization committee | https://www.tc260.org.cn/ |
| US NIST AI Risk Management | https://www.nist.gov/itl/ai-risk-management-framework |
| EU AI Act policy page | https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai |
| ISO standards catalog | https://www.iso.org/ |
| OECD AI policy observatory | https://oecd.ai/ |
| UK ICO AI guidance | https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/artificial-intelligence/ |
| US FTC AI page | https://www.ftc.gov/industry/technology/artificial-intelligence |
| DOI resolver (paper locator) | https://doi.org/ |
| arXiv (preprints, must be labeled) | https://arxiv.org/ |

Checks when using an entry point:

- Is the page the institution's official site, not a reprint/aggregator?
- Is there a clear publish/update date; if none, tag `partial`.
- Is it a draft-for-comment / draft / withdrawn version?
- Is the regulation in force, is there a transition period, does it apply to your region/industry?

## 10. What to write when no source is found

Don't write:

- "According to an industry report, 80% of enterprises…"
- "The industry widely believes…"
- "Best practice is…"
- "Generally, accuracy can reach…"

Rewrite as:

- "No verifiable public data yet; the following is an assumption to verify: …. Verification method: …."
- "Vendor states its product reaches <metric> under <conditions>; this data is not independently reproduced and cannot be generalized to this scenario."
- "In <region/industry/time>, <source> reports <data> with scope <…>; whether it applies to this scenario still needs verification."
- "We recommend first running a baseline evaluation on your own 30–100 samples before adopting this conclusion."

## 11. Verification checklist

- [ ] Every industry-data/regulation/technical-capability item has a concrete source and date.
- [ ] You opened the original, not just the search snippet.
- [ ] Region, industry, sample, time, and definition are recorded.
- [ ] Distinguished official data, vendor statements, media paraphrase, practitioner experience.
- [ ] Out-of-window items explain why they still apply.
- [ ] Key conclusions from a single source are tagged `partial`, not "consensus".
- [ ] No fabricated URL, DOI, report name, page number, or publish date.
- [ ] Your own derivations have formula, assumptions, and source IDs.
- [ ] Regulatory conclusions carry the "not a substitute for legal advice" boundary.
