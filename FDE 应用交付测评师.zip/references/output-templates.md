# Output Templates

These templates turn diagnosis into reviewable, traceable deliverables. All `<...>` are placeholders; **do not fill them with fabricated content**. Fields with no information keep `to-confirm`, with who will supply it and by when.

## 1. Diagnosis notes

```markdown
# Diagnosis Notes: <business/project name>

- Date: <YYYY-MM-DD>
- Participants: <role/name>
- Recorder: <...>
- Status: draft / confirmed

## 1. One-sentence conclusion
<Most critical judgment under current evidence; no more than 3 sentences.>

## 2. Scenario boundary
- Business goal: <...>
- Roles & decision-makers: <...>
- Trigger: <...>
- Current process: <...>
- Inputs/outputs: <...>
- Frequency/scale: <...> (source: <user-stated/file/data>)
- Cost of failure: <...>
- Constraints: <time/budget/compliance/technical>

## 3. Scenario retrospective
| Step | Trigger | Role | What seen | Judgment/action | System | Output | Failure/fallback | Cost |
|---|---|---|---|---|---|---|---|---|
| 1 | | | | | | | | |

### 3.1 Key breakpoints
1. <breakpoint> (evidence: F1/U2; impact: ...)
2. ...

### 3.2 Failure path
- Failure type: <...>
- How discovered: <...>
- Current fallback: <...>
- Acceptability: <...>

## 4. Requirement layering
- Surface request: <user's literal words>
- Real need: <who/under what conditions/what result/why>
- Business outcome: <metric/cost>
- Non-goal: <not doing in phase 1>
- Existing alternative: <manual/rule/search/legacy>; why insufficient: <...>

## 5. Fact ledger
| ID | Statement | Tag | Source/verification | Impact |
|---|---|---|---|---|
| F1 | | confirmed | | |
| U1 | | to-confirm | | |
| A1 | | assumption | | |

## 6. Initial hard-gate read
| Gate | Status | Basis/gap | Owner to fill |
|---|---|---|---|
| G1 Business owner | pass/fail/unknown | | |
| G2 Success metric | | | |
| G3 Data rights | | | |
| G4 Evaluation path | | | |
| G5 Operations & rollback | | | |
| G6 Compliance & security | | | |

## 7. Verification to-do
| Assumption/unknown | Why it affects conclusion | Verification method | Owner | Due |
|---|---|---|---|---|
| | | | | |

## 8. Next steps
- Decision point: <...>
- Materials needed: <...>
- Next meeting: <date/participants>
```

## 2. Feasibility memo

```markdown
# Feasibility Memo: <project name>

- Date: <YYYY-MM-DD>
- Version: <v0.x>
- Evaluator: <...>
- Decision-maker: <...>
- Status: recommended / under review / approved / rejected

## 1. Conclusion (for humans)
- Recommendation: proceed to PoC / validate first / discovery only / hold
- Adjusted score: <0–100> (raw: <0–100>)
- Gates: <x pass / y unknown / z fail>
- One-sentence rationale: <...>
- If a key assumption is wrong: <how conclusion changes>

## 2. Problem to solve
- Business problem: <...>
- Affected roles: <...>
- Current approach: <...>
- Cost of not doing: <...>
- Success metric & baseline: <...>

## 3. Hard gates
| Gate | Status | Evidence | Gap/next step |
|---|---|---|---|
| G1 | | | |
| ... | | | |

## 4. Seven-dimension scoring
| Dimension | Weight | Score (0–5) | Evidence level | Adjusted contribution | Basis |
|---|---:|---:|---|---:|---|
| Business value & owner | 20 | | | | |
| Data readiness | 15 | | | | |
| Technical fit | 15 | | | | |
| Evaluation readiness | 15 | | | | |
| Cost & latency | 10 | | | | |
| Risk & compliance | 15 | | | | |
| Operations & change | 10 | | | | |

Cap reasons: <...>

## 5. Options
| Option | What | Advantage | Risk | Cost/latency | Exit cost |
|---|---|---|---|---|---|
| A Don't invest / optimize process | | | | | |
| B Simplest mode | | | | | |
| C Complex mode | | | | | |

Recommendation: <...>; why not the simpler A/B: <...>; why not the more complex C: <...>.

## 6. Evidence & unknowns
- Key evidence: <C1/C2...>
- Unverified: <...>
- Counter-examples/failure samples: <...>
- Evidence gaps: <...>

## 7. Risks
| Risk | Likelihood | Impact | Mitigation | Owner |
|---|---|---|---|---|
| | | | | |

## 8. Suggested next steps
- If "validate first": 2–4 week verification plan (question/method/owner/due/pass line).
- If "proceed to PoC": PoC scope, baseline, evaluation, rollback (see PoC template).
- If "hold": blocker, unblock condition, re-evaluation time.

## 9. Attachments
- Fact ledger
- Claim Ledger
- Scoring script output
- Interview/data summary (desensitized)
```

## 3. PoC / delivery plan

```markdown
# PoC Plan: <name>

## 1. Core assumption
- We believe: <...>
- Only if <condition> holds is the approach worth continuing; otherwise stop.
- Assumptions not being validated: <...>

## 2. Scope
- User group: <...>
- Workflow: <...>
- Measurable goal: <...>
- Explicitly NOT doing: <...>
- Time box: <...>

## 3. Baseline & evaluation
- Current baseline: <manual/legacy/none>
- Measurement method: <...>
- Eval set: <source/scale/slice/version>
- Metrics: <task success/quality/latency/cost/safety>
- Pass line: <...>
- Fail line / stop condition: <...>
- Human review: <who/frequency/disagreement handling>

## 4. Approach
- Existing systems reused: <...>
- New candidate tools: <...> (why needed; alternatives; exit cost)
- Data/permissions: <...>
- Retrieval/tools/model: <...>
- Guardrails/human confirmation: <...>
- Rollback: <...>

## 5. Plan
| Week | Deliverable | Owner | Checkpoint |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| ... | | | |

## 6. Operations
- Participating users: <...>
- Training/instructions: <...>
- Feedback channel: <...>
- On-call/fallback: <...>

## 7. Decision
- Continue condition: <...>
- Stop condition: <...>
- Decision-maker / date: <...>
- Output / reusable assets: <...>
```

## 4. Industry-evidence appendix

```markdown
# Evidence Appendix: <topic>

- Search date: <YYYY-MM-DD>
- Decision supported: <...>
- Search scope: <region/industry/time/language>
- Searcher: <...>

## 1. Conclusion summary
- Supported conclusions: <...>
- Partially supported: <...>
- Unsupported: <...>
- Main conflicts/uncertainties: <...>

## 2. Claim Ledger
| ID | Claim | Type | Source (publisher/title/URL) | Publish/update | Accessed | Scope | Status |
|---|---|---|---|---|---|---|---|
| C1 | | | | | | | |

## 3. Source assessment
| Source | Tier | Independence | Recency | Scope match | Limitation |
|---|---|---|---|---|---|
| | A/B/C/D | | | | |

## 4. Cross-validation
- Independent sources supporting C1: <...>
- Sources conflicting with C1: <...>
- Conflict explanation: <scope/time/sample/definition>
- Still-missing evidence: <...>

## 5. Impact on business judgment
- If C1 holds: <...>
- If C1 doesn't hold: <...>
- Verification still needed: <...>

## 6. Citations
<list in uniform format; note access date and scope for each.>
```

## 5. One-page decision summary

```markdown
# One-pager: <project>

**Recommendation: <proceed to PoC / validate first / discovery only / hold>**

- Business problem: <one sentence>
- Real need: <who/what condition/what result>
- Why now: <evidence>
- Approach: <simplest mode + why>
- Key metric: <baseline → target>
- Hard gates: <pass/unknown/fail>
- Main risk: <...>
- Unknown/assumption: <...>
- Investment: <scope/time/people/budget>
- Next step: <who/when/what>
- If it fails: <exit/rollback/loss>
```

## 6. Scenario-retrospective table (standalone)

| Step | Trigger | Role | What seen | Judgment | Action | System | Output | Failure/fallback | Cost | Evidence |
|---|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | | |

## 7. Writing rules

- State the conclusion first, then the basis; don't write a process diary.
- Separate facts, assumptions, and suggestions into different tags/sections; don't mix.
- Every key number carries a source and scope; if none, write "to-confirm".
- Every risk states "signal / mitigation / owner", not just a risk name.
- Every next step states "who / when / deliverable", not "further communication".
- Avoid unverifiable words like "significantly improves", "greatly reduces"; use metrics, baselines, time windows.
- Don't use "industry-leading", "best practice" as arguments; give a source or cut it.
