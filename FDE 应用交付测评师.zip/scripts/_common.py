"""Shared helpers for the skill's advisory scripts.

Standard library only. These helpers validate structure and dates; they do not
verify whether a claim is true or whether a business condition is realistic.
"""

from __future__ import annotations

import json
import sys
from datetime import date
from pathlib import Path
from typing import Any


class InputError(ValueError):
    """Raised when the input does not match the documented schema."""


def load_json_file(path: str) -> dict[str, Any]:
    file_path = Path(path)
    if not file_path.is_file():
        raise InputError(f"input file not found: {path}")
    try:
        data = json.loads(file_path.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError as exc:
        raise InputError(f"invalid JSON in {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise InputError("top-level JSON value must be an object")
    return data


def parse_iso_date(value: Any, field: str, *, required: bool = True) -> date | None:
    if value in (None, ""):
        if required:
            raise InputError(f"{field} is required (YYYY-MM-DD)")
        return None
    if not isinstance(value, str):
        raise InputError(f"{field} must be a YYYY-MM-DD string")
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise InputError(f"{field} must be a valid YYYY-MM-DD date: {value!r}") from exc


def require_number(value: Any, field: str, minimum: float, maximum: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise InputError(f"{field} must be a number")
    number = float(value)
    if not minimum <= number <= maximum:
        raise InputError(f"{field} must be between {minimum:g} and {maximum:g}")
    return number


def require_text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise InputError(f"{field} must be a non-empty string")
    return value.strip()


def rounded(value: float, digits: int = 2) -> float:
    return round(float(value) + 1e-12, digits)


def write_text(path: str | None, content: str) -> None:
    if path:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return
    # Windows consoles may default to a legacy code page. Emit UTF-8 explicitly
    # so non-ASCII text and symbols do not crash the script.
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
    print(content)


def dump_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2)


def status_label(value: str) -> str:
    return {
        "pass": "Pass",
        "fail": "Fail",
        "unknown": "To be confirmed",
        "verified": "Verified",
        "partial": "Partially verified",
        "assumed": "Assumed",
        "unverified": "Unverified",
    }.get(value, value)


def markdown_table(headers: list[str], rows: list[list[Any]]) -> str:
    def cell(value: Any) -> str:
        text = "" if value is None else str(value)
        return text.replace("|", "\\|").replace("\n", " ")

    lines = [
        "| " + " | ".join(cell(h) for h in headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(cell(c) for c in row) + " |")
    return "\n".join(lines)
