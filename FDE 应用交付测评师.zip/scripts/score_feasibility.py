#!/usr/bin/env python3
"""Advisory feasibility scoring for the AI field delivery coach.

This script structurally scores a project against a fixed rubric. It does not
verify facts, does not decide whether a project should be funded, and must be
reviewed by a human. See references/feasibility-rubric.md for the anchors.
"""

from __future__ import annotations

import argparse
import sys
from datetime import date
from typing import Any

from _common import (
    InputError,
    dump_json,
    load_json_file,
    markdown_table,
    parse_iso_date,
    require_number,
    rounded,
    status_label,
    write_text,
)

TOOL_VERSION = "1.0"
RUBRIC_VERSION = "1.0"

DIMENSIONS: dict[str, dict[str, Any]] = {
    "value_and_owner": {"weight": 20.0, "label": "Business value & owner"},
    "data_readiness": {"weight": 15.0, "label": "Data readiness"},
    "technical_fit": {"weight": 15.0, "label": "Technical fit"},
    "evaluation_readiness": {"weight": 15.0, "label": "Evaluation readiness"},
    "cost_and_latency": {"weight": 10.0, "label": "Cost & latency"},
    "risk_and_compliance": {"weight": 15.0, "label": "Risk & compliance"},
    "operability_and_change": {"weight": 10.0, "label": "Operability & change"},
}

GATES: dict[str, str] = {
    "business_owner": "G1 Business owner",
    "success_metric_baseline": "G2 Success metric & baseline",
    "data_access_rights": "G3 Data rights",
    "evaluation_path": "G4 Evaluation path",
    "operational_owner": "G5 Operations & rollback",
    "compliance_review": "G6 Compliance & security",
}

CRITICAL_GATES = {"data_access_rights", "compliance_review"}

EVIDENCE_FACTORS = {
    "verified": 1.00,
    "partial": 0.85,
    "assumed": 0.55,
    "unknown": 0.25,
}

EVIDENCE_LABELS = {
    "verified": "Verified",
    "partial": "Partially verified",
    "assumed": "Assumed",
    "unknown": "Unknown",
}

LEVEL_RANK = {"hold": 0, "discovery_only": 1, "validate_first": 2, "proceed_to_poc": 3}

LEVEL_LABELS = {
    "proceed_to_poc": "Proceed to PoC (human approval still required)",
    "validate_first": "Validate first",
    "discovery_only": "Discovery only",
    "hold": "Hold",
}

NEXT_STEP = {
    "proceed_to_poc": "Write a one-page PoC plan: lock one workflow, baseline, evaluation, and rollback; only invest after the business owner approves.",
    "validate_first": "Close critical evidence gaps, the evaluation set, or compliance review within 2-4 weeks; re-score after clearing unknowns.",
    "discovery_only": "Return to the scenario retrospective and requirement layering; do not write production code first, and do not use a demo as requirement evidence.",
    "hold": "Resolve the blocking item first, or clearly decide not to proceed; do not use 'build a demo first' to bypass a hard gate.",
}


def default_weights() -> dict[str, float]:
    return {key: value["weight"] for key, value in DIMENSIONS.items()}


def build_example() -> dict[str, Any]:
    return {
        "project": "Example: after-sales knowledge assistant (fictional)",
        "as_of": "2026-10-28",
        "notes": "Example only demonstrates the input structure. All content is fictional and does not represent any real company or industry data.",
        "dimensions": {
            "value_and_owner": {
                "score": 4,
                "evidence": "verified",
                "note": "User provided a recent case and business owner; cost not yet quantified.",
            },
            "data_readiness": {
                "score": 3,
                "evidence": "partial",
                "note": "Has desensitized knowledge-base samples; update frequency and permission differences to be confirmed.",
            },
            "technical_fit": {
                "score": 4,
                "evidence": "partial",
                "note": "Retrieval QA fits the existing workflow; complex table questions not yet verified.",
            },
            "evaluation_readiness": {
                "score": 2,
                "evidence": "assumed",
                "note": "Has a preliminary definition of 'correct answer'; no evaluation set or baseline.",
            },
            "cost_and_latency": {
                "score": 3,
                "evidence": "unknown",
                "note": "Peak concurrency and latency tolerance unknown.",
            },
            "risk_and_compliance": {
                "score": 3,
                "evidence": "partial",
                "note": "Personal-data and permission risks identified; review path incomplete.",
            },
            "operability_and_change": {
                "score": 2,
                "evidence": "assumed",
                "note": "Operations owner undetermined; whether frontline will change process unknown.",
            },
        },
        "gates": {
            "business_owner": "pass",
            "success_metric_baseline": "pass",
            "data_access_rights": "unknown",
            "evaluation_path": "unknown",
            "operational_owner": "unknown",
            "compliance_review": "unknown",
        },
    }


def normalize_weights(raw: Any, warnings: list[str]) -> dict[str, float]:
    if raw is None:
        return default_weights()
    if not isinstance(raw, dict):
        raise InputError("weights must be an object")
    missing = sorted(set(DIMENSIONS) - set(raw))
    extra = sorted(set(raw) - set(DIMENSIONS))
    if missing:
        raise InputError("weights is missing dimensions: " + ", ".join(missing))
    if extra:
        raise InputError("weights has unknown dimensions: " + ", ".join(extra))
    values: dict[str, float] = {}
    for key in DIMENSIONS:
        values[key] = require_number(raw[key], f"weights.{key}", 0.000001, 1_000_000)
    total = sum(values.values())
    if total <= 0:
        raise InputError("weights must have a positive sum")
    normalized = {key: value / total * 100.0 for key, value in values.items()}
    if abs(total - 100.0) > 0.01:
        warnings.append(f"weights sum to {rounded(total)}; normalized to 100.")
    return normalized


def parse_input(data: dict[str, Any]) -> tuple[str, str, dict[str, float], dict[str, dict[str, Any]], dict[str, str], list[str]]:
    warnings: list[str] = []
    project = data.get("project", "Unnamed project")
    if not isinstance(project, str) or not project.strip():
        raise InputError("project must be a non-empty string when provided")
    as_of_raw = data.get("as_of", date.today().isoformat())
    parse_iso_date(as_of_raw, "as_of")
    as_of = str(as_of_raw)

    weights = normalize_weights(data.get("weights"), warnings)

    raw_dimensions = data.get("dimensions")
    if not isinstance(raw_dimensions, dict):
        raise InputError("dimensions must be an object")
    missing = sorted(set(DIMENSIONS) - set(raw_dimensions))
    extra = sorted(set(raw_dimensions) - set(DIMENSIONS))
    if missing:
        raise InputError("dimensions is missing: " + ", ".join(missing))
    if extra:
        raise InputError("dimensions has unknown keys: " + ", ".join(extra))

    dimensions: dict[str, dict[str, Any]] = {}
    for key, spec in DIMENSIONS.items():
        item = raw_dimensions[key]
        if not isinstance(item, dict):
            raise InputError(f"dimensions.{key} must be an object")
        score = require_number(item.get("score"), f"dimensions.{key}.score", 0, 5)
        evidence = item.get("evidence")
        if evidence not in EVIDENCE_FACTORS:
            raise InputError(
                f"dimensions.{key}.evidence must be one of: " + ", ".join(EVIDENCE_FACTORS)
            )
        note = item.get("note", "")
        if note is not None and not isinstance(note, str):
            raise InputError(f"dimensions.{key}.note must be a string")
        dimensions[key] = {"score": score, "evidence": evidence, "note": (note or "").strip()}
        if score == 0:
            warnings.append(f"{DIMENSIONS[key]['label']} is 0; confirm this means 'no information', not 'not applicable'.")
        if score == 3:
            warnings.append(
                f"{DIMENSIONS[key]['label']} is 3; a 3 means 'preliminary evidence but key conditions unverified', not a neutral default."
            )

    raw_gates = data.get("gates")
    if not isinstance(raw_gates, dict):
        raise InputError("gates must be an object")
    missing_gates = sorted(set(GATES) - set(raw_gates))
    extra_gates = sorted(set(raw_gates) - set(GATES))
    if missing_gates:
        raise InputError("gates is missing: " + ", ".join(missing_gates))
    if extra_gates:
        warnings.append("gates has unrecognized fields, ignored: " + ", ".join(extra_gates))
    gates: dict[str, str] = {}
    for key in GATES:
        status = raw_gates[key]
        if not isinstance(status, str) or status.lower() not in {"pass", "fail", "unknown"}:
            raise InputError(f"gates.{key} must be pass, fail, or unknown")
        gates[key] = status.lower()

    return project.strip(), as_of, weights, dimensions, gates, warnings


def band_from_score(score: float) -> str:
    if score >= 70:
        return "proceed_to_poc"
    if score >= 55:
        return "validate_first"
    if score >= 35:
        return "discovery_only"
    return "hold"


def score_project(data: dict[str, Any]) -> dict[str, Any]:
    project, as_of, weights, dimensions, gates, warnings = parse_input(data)

    rows: list[dict[str, Any]] = []
    raw_total = 0.0
    adjusted_total = 0.0
    covered_weight = 0.0
    for key, spec in DIMENSIONS.items():
        item = dimensions[key]
        factor = EVIDENCE_FACTORS[item["evidence"]]
        raw_contribution = weights[key] * item["score"] / 5.0
        adjusted_contribution = raw_contribution * factor
        raw_total += raw_contribution
        adjusted_total += adjusted_contribution
        if item["evidence"] in {"verified", "partial"}:
            covered_weight += weights[key]
        rows.append(
            {
                "key": key,
                "label": spec["label"],
                "weight": rounded(weights[key], 2),
                "score": item["score"],
                "evidence": item["evidence"],
                "evidence_label": EVIDENCE_LABELS[item["evidence"]],
                "factor": factor,
                "raw_contribution": rounded(raw_contribution, 2),
                "adjusted_contribution": rounded(adjusted_contribution, 2),
                "note": item["note"],
            }
        )

    raw_total = rounded(raw_total, 2)
    adjusted_total = rounded(adjusted_total, 2)
    coverage = rounded(covered_weight, 2)

    gate_counts = {"pass": 0, "fail": 0, "unknown": 0}
    gate_rows: list[dict[str, str]] = []
    for key, label in GATES.items():
        status = gates[key]
        gate_counts[status] += 1
        gate_rows.append({"key": key, "label": label, "status": status, "status_label": status_label(status)})

    level = band_from_score(adjusted_total)
    caps: list[dict[str, str]] = []

    def cap(max_level: str, code: str, reason: str) -> None:
        nonlocal level
        if LEVEL_RANK[max_level] < LEVEL_RANK[level]:
            level = max_level
        caps.append({"code": code, "reason": reason, "max_level": max_level})

    critical_fails = [GATES[k] for k in CRITICAL_GATES if gates[k] == "fail"]
    if critical_fails:
        cap("hold", "critical_gate_fail", "Hard gate failed for data rights or compliance & security: " + ", ".join(critical_fails))

    other_fails = [
        label for key, label in GATES.items() if gates[key] == "fail" and key not in CRITICAL_GATES
    ]
    if other_fails:
        cap("validate_first", "gate_fail", "One or more hard gates did not pass: " + ", ".join(other_fails))

    if gate_counts["unknown"] >= 3:
        cap(
            "validate_first",
            "many_unknown_gates",
            f"{gate_counts['unknown']} hard gates are still unknown; gather evidence before treating them as pass.",
        )

    if coverage < 50:
        cap(
            "validate_first",
            "low_evidence_coverage",
            f"Verified/partially-verified weight coverage is only {coverage:g}%, below 50%.",
        )

    by_key = {row["key"]: row for row in rows}
    if by_key["value_and_owner"]["score"] <= 1:
        cap("discovery_only", "weak_value", "Business value & owner <= 1: confirm the real need, owner, and cost first.")
    if by_key["data_readiness"]["score"] <= 1:
        cap("validate_first", "weak_data", "Data readiness <= 1: do data due diligence before PoC.")
    if by_key["evaluation_readiness"]["score"] <= 1:
        cap("validate_first", "weak_eval", "Evaluation readiness <= 1: no way to judge right/wrong, cannot enter PoC.")
    if by_key["risk_and_compliance"]["score"] <= 1:
        cap("validate_first", "weak_risk", "Risk & compliance <= 1: complete classification and review path first.")

    if level == "proceed_to_poc" and gate_counts["unknown"] > 1:
        cap(
            "validate_first",
            "unresolved_gates_for_proceed",
            "To enter PoC, at most 1 hard gate may remain unknown, and a verification plan is required.",
        )

    if level == "proceed_to_poc" and coverage < 65:
        cap(
            "validate_first",
            "low_coverage_for_proceed",
            f"To enter PoC, evidence coverage should be at least 65%; current is {coverage:g}%.",
        )

    if raw_total - adjusted_total >= 20:
        warnings.append(
            f"Evidence-adjusted score is {rounded(raw_total - adjusted_total)} points below the raw score; the conclusion is sensitive to unverified assumptions."
        )
    if gate_counts["unknown"] == 1 and level == "proceed_to_poc":
        warnings.append("One hard gate is still unknown; state the conclusion conditionally and close it before PoC.")
    if gate_counts["fail"] == 0 and gate_counts["unknown"] == 0 and coverage >= 80:
        confidence = "high"
    elif coverage >= 50 and gate_counts["fail"] <= 1:
        confidence = "medium"
    else:
        confidence = "low"

    review_questions: list[str] = []
    for gate in gate_rows:
        if gate["status"] == "fail":
            review_questions.append(f"{gate['label']} failed: what is the blocker, and who can clear it by when?")
        elif gate["status"] == "unknown":
            review_questions.append(f"{gate['label']} unknown: what evidence is needed to judge pass/fail?")
    for row in rows:
        if row["evidence"] in {"assumed", "unknown"}:
            suffix = f" ({row['note']})" if row["note"] else ""
            review_questions.append(f"{row['label']} has insufficient evidence{suffix}; what evidence would change the conclusion?")
    review_questions.extend(
        [
            "If the PoC fails, is the loss tolerable? Can we get a clear signal within 2-6 weeks?",
            "Is there a simpler non-AI option? Why is it insufficient?",
            "Who owns operations and incident responsibility after launch?",
        ]
    )
    # Keep the list useful rather than exhaustive.
    review_questions = list(dict.fromkeys(review_questions))[:8]

    conditional = level == "proceed_to_poc" and gate_counts["unknown"] > 0
    return {
        "tool": "score_feasibility",
        "tool_version": TOOL_VERSION,
        "rubric_version": RUBRIC_VERSION,
        "advisory_only": True,
        "not_a_final_decision": True,
        "project": project,
        "as_of": as_of,
        "scores": {
            "raw": raw_total,
            "adjusted": adjusted_total,
            "band": level,
            "band_label": LEVEL_LABELS[level],
            "confidence": confidence,
            "conditional": conditional,
            "formula": "raw = sum(weight * score/5); adjusted = sum(weight * score/5 * evidence_factor)",
        },
        "gate_summary": gate_counts,
        "gates": gate_rows,
        "dimensions": rows,
        "caps": caps,
        "evidence_coverage_pct": coverage,
        "warnings": list(dict.fromkeys(warnings)),
        "review_questions": review_questions,
        "recommended_next_step": NEXT_STEP[level],
        "disclaimer": (
            "This is a structured advisory signal, not a go/no-go decision. The script does not verify "
            "the truth of facts and does not understand decision context; the final judgment must be made "
            "by a named human owner using evidence, risk, and exit cost, recording any override of the "
            "script's conclusion."
        ),
    }


def render_markdown(result: dict[str, Any]) -> str:
    scores = result["scores"]
    gates = result["gates"]
    lines = [
        "# Feasibility Score (Advisory Signal)",
        "",
        f"> {result['disclaimer']}",
        "",
        f"- Project: {result['project']}",
        f"- As of: {result['as_of']}",
        f"- Conclusion signal: **{scores['band_label']}** (`{scores['band']}`)",
        f"- Adjusted score: **{scores['adjusted']:.2f} / 100**; raw score: {scores['raw']:.2f}; confidence: {scores['confidence']}",
        f"- Hard gates: {result['gate_summary']['pass']} pass / {result['gate_summary']['unknown']} unknown / {result['gate_summary']['fail']} fail",
        f"- Evidence coverage: {result['evidence_coverage_pct']:.1f}%",
        "",
        "## Hard Gates",
        "",
        markdown_table(
            ["Hard gate", "Status"],
            [[g["label"], g["status_label"]] for g in gates],
        ),
        "",
        "## Seven-Dimension Scores",
        "",
        markdown_table(
            ["Dimension", "Weight", "Score", "Evidence", "Raw contrib.", "Adj. contrib.", "Note"],
            [
                [
                    row["label"],
                    f"{row['weight']:.2f}",
                    f"{row['score']:g}",
                    row["evidence_label"],
                    f"{row['raw_contribution']:.2f}",
                    f"{row['adjusted_contribution']:.2f}",
                    row["note"] or "-",
                ]
                for row in result["dimensions"]
            ],
        ),
        "",
        "## Cap Reasons",
        "",
    ]
    if result["caps"]:
        lines.extend(
            markdown_table(
                ["Rule", "Reason", "Max level"],
                [[c["code"], c["reason"], LEVEL_LABELS[c["max_level"]]] for c in result["caps"]],
            ).splitlines()
        )
    else:
        lines.append("No cap rules triggered.")

    lines.extend(["", "## Warnings", ""])
    lines.extend([f"- {w}" for w in result["warnings"]] or ["- None."])

    lines.extend(["", "## Questions for Human Review", ""])
    lines.extend([f"{i}. {q}" for i, q in enumerate(result["review_questions"], 1)])

    lines.extend(
        [
            "",
            "## Recommended Next Step",
            "",
            result["recommended_next_step"],
            "",
            "> Do not treat this page as the decision record. The final conclusion should go into a "
            "feasibility memo that lists evidence, counter-examples, unknowns, risks, exit cost, and the decision owner.",
        ]
    )
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Advisory feasibility scoring; output is not a final decision.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python score_feasibility.py --example\n"
            "  python score_feasibility.py --input assets/feasibility-input.example.json --format markdown\n"
        ),
    )
    parser.add_argument("--input", help="Input JSON file")
    parser.add_argument("--format", choices=("json", "markdown"), default="json", help="Output format")
    parser.add_argument("--output", help="Write to file; print to stdout if omitted")
    parser.add_argument("--example", action="store_true", help="Print example input JSON")
    args = parser.parse_args(argv)

    try:
        if args.example:
            if args.input:
                parser.error("--example cannot be used together with --input")
            write_text(args.output, dump_json(build_example()))
            return 0
        if not args.input:
            parser.error("need --input, or use --example to see the input structure")
        data = load_json_file(args.input)
        result = score_project(data)
        content = dump_json(result) if args.format == "json" else render_markdown(result)
        write_text(args.output, content)
        return 0
    except InputError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
