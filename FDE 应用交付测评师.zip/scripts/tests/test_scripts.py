from __future__ import annotations

import sys
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPTS))

import audit_brief  # noqa: E402
import audit_evidence  # noqa: E402
import score_feasibility  # noqa: E402


class FeasibilityTests(unittest.TestCase):
    def test_example_is_advisory_and_exposes_caps(self) -> None:
        result = score_feasibility.score_project(score_feasibility.build_example())
        self.assertTrue(result["advisory_only"])
        self.assertTrue(result["not_a_final_decision"])
        self.assertLess(result["scores"]["adjusted"], result["scores"]["raw"])
        codes = {cap["code"] for cap in result["caps"]}
        self.assertIn("many_unknown_gates", codes)

    def test_critical_gate_failure_caps_to_hold(self) -> None:
        data = score_feasibility.build_example()
        for key in data["dimensions"]:
            data["dimensions"][key] = {"score": 5, "evidence": "verified", "note": "test"}
        data["gates"] = {key: "pass" for key in score_feasibility.GATES}
        data["gates"]["data_access_rights"] = "fail"
        result = score_feasibility.score_project(data)
        self.assertEqual(result["scores"]["band"], "hold")
        self.assertEqual(result["scores"]["adjusted"], 100.0)
        self.assertIn("critical_gate_fail", {cap["code"] for cap in result["caps"]})

    def test_missing_dimension_is_rejected(self) -> None:
        data = score_feasibility.build_example()
        del data["dimensions"]["data_readiness"]
        with self.assertRaises(score_feasibility.InputError):
            score_feasibility.score_project(data)

    def test_low_coverage_blocks_proceed(self) -> None:
        data = score_feasibility.build_example()
        for key in data["dimensions"]:
            data["dimensions"][key] = {"score": 5, "evidence": "verified", "note": "test"}
        data["gates"] = {key: "pass" for key in score_feasibility.GATES}
        for key in ("data_readiness", "risk_and_compliance", "operability_and_change"):
            data["dimensions"][key]["evidence"] = "unknown"
        result = score_feasibility.score_project(data)
        self.assertGreaterEqual(result["scores"]["adjusted"], 70)
        self.assertLess(result["evidence_coverage_pct"], 65)
        self.assertEqual(result["scores"]["band"], "validate_first")
        self.assertIn("low_coverage_for_proceed", {cap["code"] for cap in result["caps"]})


class EvidenceTests(unittest.TestCase):
    def test_example_passes_structure(self) -> None:
        result = audit_evidence.audit(audit_evidence.build_example())
        self.assertEqual(result["summary"]["errors"], 0)
        self.assertIn(result["verdict"], {"structure_ok", "pass_with_warnings"})
        self.assertIn("missing_effective_date", {f["code"] for f in result["findings"]})

    def test_vendor_industry_data_is_blocked(self) -> None:
        data = audit_evidence.build_example()
        data["claims"] = [
            {
                "id": "C1",
                "claim": "Industry adoption is very high.",
                "claim_type": "industry_data",
                "source": {
                    "title": "Vendor report",
                    "publisher": "Vendor",
                    "url": "https://vendor.example/report",
                    "source_type": "vendor",
                    "published": "2026-01-01",
                    "accessed": "2026-10-28",
                },
                "scope": "Global / example",
                "status": "partial",
            }
        ]
        result = audit_evidence.audit(data)
        self.assertGreaterEqual(result["summary"]["errors"], 1)
        self.assertIn("industry_source_grade", {f["code"] for f in result["findings"]})

    def test_practitioner_experience_cannot_be_verified(self) -> None:
        data = audit_evidence.build_example()
        data["claims"] = [
            {
                "id": "C1",
                "claim": "Frontline staff prefer natural language.",
                "claim_type": "practitioner_experience",
                "source": {
                    "source_type": "practitioner",
                    "reference": "2026-10-28 interview",
                    "accessed": "2026-10-28",
                },
                "scope": "Example team",
                "status": "verified",
            }
        ]
        result = audit_evidence.audit(data)
        self.assertIn("practitioner_verified", {f["code"] for f in result["findings"]})

    def test_user_fact_does_not_need_url(self) -> None:
        data = audit_evidence.build_example()
        data["claims"] = [
            {
                "id": "C1",
                "claim": "The current process requires manual reconciliation.",
                "claim_type": "user_fact",
                "source": {
                    "source_type": "user_input",
                    "reference": "2026-10-28 interview",
                    "accessed": "2026-10-28",
                },
                "scope": "Example team",
                "status": "verified",
            }
        ]
        result = audit_evidence.audit(data)
        self.assertEqual(result["summary"]["errors"], 0)


class BriefTests(unittest.TestCase):
    def test_example_has_no_errors(self) -> None:
        result = audit_brief.audit(audit_brief.build_example())
        self.assertEqual(result["summary"]["errors"], 0)
        self.assertGreaterEqual(result["completeness"], 80)
        self.assertGreater(result["summary"]["warnings"], 0)

    def test_proposed_tool_in_confirmed_fact_is_blocked(self) -> None:
        data = audit_brief.build_example()
        data["business_context"]["confirmed"][0]["statement"] += " using vector retrieval."
        result = audit_brief.audit(data)
        codes = {f["code"] for f in result["findings"]}
        self.assertIn("proposed_tool_in_fact", codes)
        self.assertGreaterEqual(result["summary"]["errors"], 1)

    def test_missing_non_goals_is_blocked(self) -> None:
        data = audit_brief.build_example()
        data["non_goals"] = []
        result = audit_brief.audit(data)
        self.assertIn("missing_non_goals", {f["code"] for f in result["findings"]})

    def test_unknown_evidence_reference_is_blocked(self) -> None:
        data = audit_brief.build_example()
        data["workflow"][0]["evidence"] = ["F999"]
        result = audit_brief.audit(data)
        self.assertIn("unknown_evidence_ref", {f["code"] for f in result["findings"]})

    def test_zero_baseline_is_not_treated_as_placeholder(self) -> None:
        data = audit_brief.build_example()
        for metric in data["success_metrics"]:
            metric["baseline"] = 0
            metric["target"] = 1
        result = audit_brief.audit(data)
        self.assertNotIn("metric_incomplete", {f["code"] for f in result["findings"]})

    def test_blocking_must_be_boolean(self) -> None:
        data = audit_brief.build_example()
        data["business_context"]["unknowns"][0]["blocking"] = "false"
        result = audit_brief.audit(data)
        self.assertIn("invalid_blocking", {f["code"] for f in result["findings"]})


if __name__ == "__main__":
    unittest.main()
