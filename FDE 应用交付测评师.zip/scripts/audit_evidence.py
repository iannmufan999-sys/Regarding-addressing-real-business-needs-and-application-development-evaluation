#!/usr/bin/env python3
"""Advisory evidence-ledger audit.

Checks structure, source classification, dates, and basic recency rules. It
cannot open URLs and cannot decide whether a claim is true. Findings are check
items for a human reviewer, not a final judgment.
"""

from __future__ import annotations

import argparse
import re
import sys
from datetime import date
from typing import Any
from urllib.parse import urlparse

from _common import (
    InputError,
    dump_json,
    load_json_file,
    markdown_table,
    parse_iso_date,
    require_text,
    rounded,
    status_label,
    write_text,
)

TOOL_VERSION = "1.0"

CLAIM_TYPES = {
    "industry_data",
    "technical_capability",
    "regulation",
    "vendor_claim",
    "user_fact",
    "practitioner_experience",
}

WEB_SOURCE_TYPES = {"official", "standard", "peer_reviewed", "vendor", "media", "blog", "other"}
ALL_SOURCE_TYPES = WEB_SOURCE_TYPES | {"user_input", "practitioner"}

STATUSES = {"verified", "partial", "unverified"}

RECENCY_DAYS = {
    "industry_data": 730,
    "technical_capability": 365,
    "regulation": 730,
    "vendor_claim": 180,
    "user_fact": None,
    "practitioner_experience": None,
}

PRIVATE_HOSTS = {"localhost", "127.0.0.1", "0.0.0.0", "::1"}
SEARCH_HOST_MARKERS = ("google.", "bing.com", "baidu.com", "duckduckgo.com", "sogou.com")
SHORTENER_HOSTS = {"bit.ly", "t.co", "goo.gl", "tinyurl.com", "dwz.cn", "url.cn"}


def build_example() -> dict[str, Any]:
    return {
        "as_of": "2026-10-28",
        "notes": "Example only demonstrates the ledger structure; all organizations, people, and sources are fictional placeholders and must not be cited.",
        "claims": [
            {
                "id": "C1",
                "claim": "After-sales knowledge currently sits in three internal sources; frontline staff compare them manually.",
                "claim_type": "user_fact",
                "source": {
                    "source_type": "user_input",
                    "reference": "2026-10-28 interview, after-sales supervisor (fictional example)",
                    "accessed": "2026-10-28",
                },
                "scope": "Fictional example company / after-sales team",
                "status": "verified",
                "notes": "User-stated; valid only for this case, not to be generalized as industry data.",
            },
            {
                "id": "C2",
                "claim": "Some frontline staff prefer natural-language questions over field-based search.",
                "claim_type": "practitioner_experience",
                "source": {
                    "source_type": "practitioner",
                    "reference": "2026-10-28 interview, 2 frontline staff (fictional example)",
                    "accessed": "2026-10-28",
                },
                "scope": "Fictional example company / after-sales team",
                "status": "partial",
                "notes": "Experience-based judgment; needs usability testing to confirm.",
            },
            {
                "id": "C3",
                "claim": "[Placeholder example] A regulator published AI usage guidance.",
                "claim_type": "regulation",
                "source": {
                    "title": "Placeholder example guidance (not a real document)",
                    "publisher": "Placeholder organization (not real)",
                    "url": "https://example.gov/ai-guidance",
                    "source_type": "official",
                    "published": "2026-01-01",
                    "updated": "2026-06-01",
                    "accessed": "2026-10-28",
                },
                "scope": "Placeholder example / not applicable",
                "status": "partial",
                "notes": "Demonstrates fields only; must be replaced with a real official page and re-verified before citing.",
            },
        ],
    }


def add_finding(findings: list[dict[str, Any]], severity: str, code: str, message: str, claim_id: str | None = None) -> None:
    findings.append({"severity": severity, "code": code, "claim_id": claim_id, "message": message})


def validate_url(url: Any, claim_id: str, findings: list[dict[str, Any]]) -> str:
    text = require_text(url, f"claims[{claim_id}].source.url")
    parsed = urlparse(text)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        add_finding(findings, "error", "invalid_url", "URL must be a publicly accessible http(s) address.", claim_id)
        return text
    host = (parsed.hostname or "").lower()
    if host in PRIVATE_HOSTS or host.endswith(".local"):
        add_finding(findings, "error", "private_url", "A localhost/intranet address cannot be treated as a verifiable public source.", claim_id)
    if any(marker in host for marker in SEARCH_HOST_MARKERS) and (
        "/search" in parsed.path or parsed.query
    ):
        add_finding(findings, "warning", "search_result_url", "This is a search-results page, not the original source; cite the specific original page.", claim_id)
    if host in SHORTENER_HOSTS:
        add_finding(findings, "warning", "short_url", "Short links cannot reliably locate the original text; use the final original URL.", claim_id)
    return text


def parse_optional_date(value: Any, field: str, claim_id: str, findings: list[dict[str, Any]]) -> date | None:
    try:
        return parse_iso_date(value, field, required=False)
    except InputError as exc:
        add_finding(findings, "error", "invalid_date", str(exc), claim_id)
        return None


def audit(data: dict[str, Any]) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    as_of_raw = data.get("as_of")
    as_of = parse_optional_date(as_of_raw, "as_of", "-", findings)
    if as_of is None:
        raise InputError("as_of is required (YYYY-MM-DD)")
    as_of_text = str(as_of_raw)

    claims = data.get("claims")
    if not isinstance(claims, list) or not claims:
        raise InputError("claims must be a non-empty array")

    seen_ids: set[str] = set()
    seen_claim_text: dict[str, str] = {}
    publishers: list[str] = []
    claim_rows: list[dict[str, Any]] = []
    type_counts: dict[str, int] = {}
    status_counts: dict[str, int] = {"verified": 0, "partial": 0, "unverified": 0}
    source_type_counts: dict[str, int] = {}

    for index, item in enumerate(claims):
        if not isinstance(item, dict):
            raise InputError(f"claims[{index}] must be an object")
        claim_id = item.get("id")
        if not isinstance(claim_id, str) or not claim_id.strip():
            raise InputError(f"claims[{index}].id must be a non-empty string")
        claim_id = claim_id.strip()
        if claim_id in seen_ids:
            add_finding(findings, "error", "duplicate_id", f"duplicate claim id: {claim_id}", claim_id)
            continue
        seen_ids.add(claim_id)

        claim_text = require_text(item.get("claim"), f"claims[{claim_id}].claim")
        normalized_claim = re.sub(r"\s+", " ", claim_text).strip()
        if normalized_claim in seen_claim_text:
            add_finding(
                findings,
                "warning",
                "duplicate_claim",
                f"duplicate claim text with {seen_claim_text[normalized_claim]}.",
                claim_id,
            )
        else:
            seen_claim_text[normalized_claim] = claim_id

        claim_type = item.get("claim_type")
        if claim_type not in CLAIM_TYPES:
            add_finding(
                findings,
                "error",
                "invalid_claim_type",
                "claim_type must be one of: " + ", ".join(sorted(CLAIM_TYPES)),
                claim_id,
            )
            claim_type = "other"
        type_counts[claim_type] = type_counts.get(claim_type, 0) + 1

        status = item.get("status")
        if status not in STATUSES:
            add_finding(findings, "error", "invalid_status", "status must be verified/partial/unverified.", claim_id)
            status = "unverified"
        status_counts[status] += 1

        scope = item.get("scope", "")
        if scope is not None and not isinstance(scope, str):
            add_finding(findings, "error", "invalid_scope", "scope must be a string.", claim_id)
            scope = ""
        scope = (scope or "").strip()
        if claim_type in {"industry_data", "regulation"} and not scope:
            add_finding(findings, "error", "missing_scope", "Industry data / regulation must state region, industry, time, or applicable object.", claim_id)

        source = item.get("source")
        if not isinstance(source, dict):
            add_finding(findings, "error", "missing_source", "Every claim must have a source object.", claim_id)
            source = {}

        source_type = source.get("source_type")
        if source_type not in ALL_SOURCE_TYPES:
            add_finding(
                findings,
                "error",
                "invalid_source_type",
                "source_type must be one of: " + ", ".join(sorted(ALL_SOURCE_TYPES)),
                claim_id,
            )
            source_type = "other"
        source_type_counts[source_type] = source_type_counts.get(source_type, 0) + 1

        age_days: int | None = None
        stale = False
        date_basis = None
        publisher = ""
        host = ""

        if claim_type == "user_fact":
            if source_type != "user_input":
                add_finding(findings, "error", "user_fact_source", "user_fact must use source_type user_input.", claim_id)
            reference = source.get("reference")
            if not isinstance(reference, str) or not reference.strip():
                add_finding(findings, "error", "missing_reference", "user_fact must include reference (interview date / role / file path).", claim_id)
            accessed = parse_optional_date(source.get("accessed"), f"claims[{claim_id}].source.accessed", claim_id, findings)
            if accessed is None:
                add_finding(findings, "warning", "missing_accessed", "user_fact should record an accessed date.", claim_id)
            if source.get("url"):
                validate_url(source.get("url"), claim_id, findings)
        elif claim_type == "practitioner_experience":
            if source_type != "practitioner":
                add_finding(
                    findings,
                    "error",
                    "practitioner_source",
                    "practitioner_experience must use source_type practitioner.",
                    claim_id,
                )
            reference = source.get("reference")
            if not isinstance(reference, str) or not reference.strip():
                add_finding(findings, "error", "missing_reference", "Practitioner experience must include reference (interview date / role / scenario).", claim_id)
            if status == "verified":
                add_finding(
                    findings,
                    "error",
                    "practitioner_verified",
                    "Practitioner experience must not be marked verified as if it were fact; use partial/unverified and treat it as an assumption.",
                    claim_id,
                )
            if source.get("url"):
                validate_url(source.get("url"), claim_id, findings)
        else:
            if source_type in {"user_input", "practitioner"}:
                add_finding(
                    findings,
                    "error",
                    "wrong_source_type",
                    f"{claim_type} cannot use {source_type} sources; cite public / official / primary material.",
                    claim_id,
                )
            publisher = require_text(source.get("publisher"), f"claims[{claim_id}].source.publisher")
            require_text(source.get("title"), f"claims[{claim_id}].source.title")
            url = validate_url(source.get("url"), claim_id, findings)
            host = (urlparse(url).hostname or "").lower()
            publishers.append(publisher)

            published = parse_optional_date(source.get("published"), f"claims[{claim_id}].source.published", claim_id, findings)
            updated = parse_optional_date(source.get("updated"), f"claims[{claim_id}].source.updated", claim_id, findings)
            accessed = parse_optional_date(source.get("accessed"), f"claims[{claim_id}].source.accessed", claim_id, findings)
            if published is None and updated is None:
                add_finding(findings, "error", "missing_date", "Public sources need at least a published or updated date.", claim_id)
            if accessed is None:
                add_finding(findings, "error", "missing_accessed", "Public sources must record an accessed date.", claim_id)
            if published and updated and updated < published:
                add_finding(findings, "error", "date_order", "updated cannot be earlier than published.", claim_id)

            date_basis = updated or published
            if date_basis:
                age_days = (as_of - date_basis).days
                if age_days < 0:
                    add_finding(findings, "warning", "future_date", "Source date is later than the assessment date; please check the dates.", claim_id)
                limit = RECENCY_DAYS.get(claim_type)
                if limit is not None and age_days > limit:
                    stale = True
                    add_finding(
                        findings,
                        "warning",
                        "stale_source",
                        f"Source is {age_days} days old, beyond the default recency window of {limit} days; find a newer version, or downgrade status to partial and explain why it still applies.",
                        claim_id,
                    )
            if accessed and date_basis and accessed < date_basis:
                add_finding(findings, "warning", "accessed_before_source", "accessed is earlier than the source date; please check.", claim_id)

            if claim_type == "industry_data" and source_type not in {"official", "standard", "peer_reviewed"}:
                add_finding(
                    findings,
                    "error",
                    "industry_source_grade",
                    "industry_data can only use official / standard / peer-reviewed sources; vendor, media, or blog alone cannot support it.",
                    claim_id,
                )
            if claim_type == "regulation":
                if source_type not in {"official", "standard"}:
                    add_finding(
                        findings,
                        "error",
                        "regulation_source_grade",
                        "regulation can only use official / standard sources; media interpretation cannot replace the original text.",
                        claim_id,
                    )
                effective = parse_optional_date(
                    source.get("effective_date"), f"claims[{claim_id}].source.effective_date", claim_id, findings
                )
                if effective is None:
                    add_finding(
                        findings,
                        "warning",
                        "missing_effective_date",
                        "Regulation should record effective_date, and confirm the currently in-force version / transition period.",
                        claim_id,
                    )
                elif effective > as_of:
                    add_finding(findings, "warning", "not_yet_effective", "This regulation is not yet in force on the assessment date.", claim_id)
            if claim_type == "technical_capability":
                if source_type in {"media", "blog", "other"} and status == "verified":
                    add_finding(
                        findings,
                        "error",
                        "weak_tech_source",
                        "When technical capability is marked verified, media / blog / other sources alone are insufficient; use official docs, standards, or papers.",
                        claim_id,
                    )
                elif source_type == "vendor":
                    add_finding(
                        findings,
                        "warning",
                        "vendor_tech_claim",
                        "Vendor docs only prove what that vendor claims under its own conditions; label it 'vendor statement' and seek independent verification.",
                        claim_id,
                    )
            if claim_type == "vendor_claim":
                if source_type != "vendor":
                    add_finding(findings, "warning", "vendor_claim_source", "vendor_claim should normally cite a vendor source.", claim_id)
                if status == "verified":
                    add_finding(
                        findings,
                        "warning",
                        "vendor_claim_verified",
                        "verified only means 'the vendor does state this', not that the statement is true; this must be stated in the report.",
                        claim_id,
                    )
            if status == "verified" and source_type in {"media", "blog", "other"}:
                add_finding(
                    findings,
                    "error",
                    "weak_source_verified",
                    "Media / blog / other sources alone cannot mark a claim as verified.",
                    claim_id,
                )

        claim_rows.append(
            {
                "id": claim_id,
                "claim_type": claim_type,
                "status": status,
                "status_label": status_label(status),
                "source_type": source_type,
                "publisher": publisher,
                "host": host,
                "age_days": age_days,
                "stale": stale,
                "scope_present": bool(scope),
            }
        )

    if len(publishers) >= 3 and len(set(publishers)) == 1:
        add_finding(
            findings,
            "warning",
            "single_publisher",
            "Multiple public claims come from the same publisher; add independent sources to avoid single-source bias.",
        )
    vendor_count = source_type_counts.get("vendor", 0)
    if vendor_count and vendor_count == sum(source_type_counts.values()):
        add_finding(findings, "warning", "all_vendor", "All claims come from vendor sources; cannot serve as independent industry evidence.")

    errors = [f for f in findings if f["severity"] == "error"]
    warnings = [f for f in findings if f["severity"] == "warning"]

    if errors:
        verdict = "blocking_issues"
        verdict_label = "Blocking issues need fixing"
    elif warnings:
        verdict = "pass_with_warnings"
        verdict_label = "Structure passes, but items need human review"
    else:
        verdict = "structure_ok"
        verdict_label = "Structure passes (content still needs human verification)"

    return {
        "tool": "audit_evidence",
        "tool_version": TOOL_VERSION,
        "advisory_only": True,
        "not_a_final_decision": True,
        "as_of": as_of_text,
        "verdict": verdict,
        "verdict_label": verdict_label,
        "summary": {
            "claims": len(claim_rows),
            "errors": len(errors),
            "warnings": len(warnings),
            "by_type": type_counts,
            "by_status": status_counts,
            "by_source_type": source_type_counts,
        },
        "findings": findings,
        "claims": claim_rows,
        "source_diversity": {
            "public_publishers": len(set(publishers)),
            "publishers": sorted(set(publishers)),
        },
        "disclaimer": (
            "This check only verifies ledger structure and source classification; it does not open URLs, "
            "does not judge truth, and is not compliance or legal advice. Every source still needs a human "
            "to open the original and verify; findings are a review checklist, not a final veto."
        ),
    }


def render_markdown(result: dict[str, Any]) -> str:
    summary = result["summary"]
    lines = [
        "# Evidence Ledger Check (Advisory)",
        "",
        f"> {result['disclaimer']}",
        "",
        f"- As of: {result['as_of']}",
        f"- Conclusion: **{result['verdict_label']}** (`{result['verdict']}`)",
        f"- Claims: {summary['claims']}; errors: {summary['errors']}; warnings: {summary['warnings']}",
        f"- Independent public publishers: {result['source_diversity']['public_publishers']}",
        "",
        "## Claim Overview",
        "",
        markdown_table(
            ["ID", "Type", "Status", "Source type", "Publisher", "Age", "Stale"],
            [
                [
                    row["id"],
                    row["claim_type"],
                    row["status_label"],
                    row["source_type"],
                    row["publisher"] or "-",
                    f"{row['age_days']} days" if row["age_days"] is not None else "-",
                    "Yes" if row["stale"] else "No",
                ]
                for row in result["claims"]
            ],
        ),
    ]
    if result["findings"]:
        lines.extend(["", "## Findings", ""])
        lines.append(
            markdown_table(
                ["Severity", "ID", "Code", "Message"],
                [
                    [f["severity"], f["claim_id"] or "-", f["code"], f["message"]]
                    for f in result["findings"]
                ],
            )
        )
    else:
        lines.extend(["", "## Findings", "", "No structural issues found. A human must still open the sources and verify content."])

    lines.extend(
        [
            "",
            "## Human Review Focus",
            "",
            "- Did you open the original URL for each source, not just a search snippet?",
            "- Do the region / industry / sample / time scopes match your decision?",
            "- Were vendor statements mistakenly written as independent facts?",
            "- For sources past the recency window, is there a reason stated for why they still apply?",
            "- Are there counter-examples / conflicting sources missing from the ledger?",
        ]
    )
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Check evidence-ledger structure; does not verify content truth.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python audit_evidence.py --example\n"
            "  python audit_evidence.py --input assets/evidence-ledger.example.json --format markdown\n"
        ),
    )
    parser.add_argument("--input", help="Input JSON file")
    parser.add_argument("--format", choices=("json", "markdown"), default="json", help="Output format")
    parser.add_argument("--output", help="Write to file; print to stdout if omitted")
    parser.add_argument("--example", action="store_true", help="Print example ledger JSON")
    args = parser.parse_args(argv)

    try:
        if args.example:
            if args.input:
                parser.error("--example cannot be used together with --input")
            write_text(args.output, dump_json(build_example()))
            return 0
        if not args.input:
            parser.error("need --input, or use --example to see the ledger structure")
        data = load_json_file(args.input)
        result = audit(data)
        content = dump_json(result) if args.format == "json" else render_markdown(result)
        write_text(args.output, content)
        return 1 if result["summary"]["errors"] else 0
    except InputError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
