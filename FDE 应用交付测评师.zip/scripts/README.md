# Advisory script notes

These scripts only do **structured checks and scoring**; they do not verify factual truth and do not replace business judgment. All output must be reviewed by a human and presented together with unknowns, counter-examples, evidence, and exit costs.

## Environment

- Python 3.10+ (the bundled repo/DSH Python 3.12 works).
- Standard library only; no packages to install, no network needed.
- Scripts do not open URLs, do not crawl web pages, do not call models.

## Files

| File | Purpose |
|---|---|
| `score_feasibility.py` | Compute advisory score by 7 dimensions / 6 hard gates, apply cap rules |
| `audit_evidence.py` | Check Claim Ledger structure, source grading, dates, recency |
| `audit_brief.py` | Check requirement-brief completeness, evidence references, anti-fabrication tags |
| `_common.py` | Shared validation / output helpers |
| `tests/test_scripts.py` | Standard-library unittest |

## Common exit codes

| Exit code | Meaning |
|---|---|
| 0 | Ran successfully; `audit_*` may still emit warnings |
| 1 | `audit_*` found blocking items needing correction (not a final veto) |
| 2 | Input structure error, cannot evaluate |

`score_feasibility.py` always returns 0 (unless input is malformed), because a score is not pass/fail.

## 1. score_feasibility.py

### Input

```json
{
  "project": "project name",
  "as_of": "2026-10-28",
  "dimensions": {
    "value_and_owner":       {"score": 0, "evidence": "verified|partial|assumed|unknown", "note": "basis"},
    "data_readiness":        {"score": 0, "evidence": "...", "note": "..."},
    "technical_fit":         {"score": 0, "evidence": "...", "note": "..."},
    "evaluation_readiness":  {"score": 0, "evidence": "...", "note": "..."},
    "cost_and_latency":      {"score": 0, "evidence": "...", "note": "..."},
    "risk_and_compliance":   {"score": 0, "evidence": "...", "note": "..."},
    "operability_and_change":{"score": 0, "evidence": "...", "note": "..."}
  },
  "gates": {
    "business_owner": "pass|fail|unknown",
    "success_metric_baseline": "pass|fail|unknown",
    "data_access_rights": "pass|fail|unknown",
    "evaluation_path": "pass|fail|unknown",
    "operational_owner": "pass|fail|unknown",
    "compliance_review": "pass|fail|unknown"
  }
}
```

- All 7 dimensions required; score 0–5.
- Default weights 20/15/15/15/10/15/10; override with `"weights"`, script normalizes to 100.
- Evidence factors: verified 1.00, partial 0.85, assumed 0.55, unknown 0.25.
- Cap rules in `references/feasibility-rubric.md`; script output lists triggered rules.

### Commands

```bash
python scripts/score_feasibility.py --example
python scripts/score_feasibility.py --input assets/feasibility-input.example.json
python scripts/score_feasibility.py --input assets/feasibility-input.example.json --format markdown
python scripts/score_feasibility.py --input my.json --format markdown --output report.md
```

### Reading the output

- `scores.raw`: score if all judgments hold.
- `scores.adjusted`: score discounted by evidence.
- `scores.band`: script signal; not a go/no-go decision.
- `caps`: which rules lowered the level, and why.
- `warnings`: default-3 traps, evidence gaps, weight normalization, etc.
- `review_questions`: questions human review must answer.

## 2. audit_evidence.py

### Input

```json
{
  "as_of": "2026-10-28",
  "claims": [
    {
      "id": "C1",
      "claim": "one-sentence claim",
      "claim_type": "industry_data|technical_capability|regulation|vendor_claim|user_fact|practitioner_experience",
      "source": {
        "title": "title",
        "publisher": "publisher",
        "url": "https://...",
        "source_type": "official|standard|peer_reviewed|vendor|media|blog|other|user_input|practitioner",
        "published": "YYYY-MM-DD",
        "updated": "YYYY-MM-DD",
        "accessed": "YYYY-MM-DD",
        "effective_date": "YYYY-MM-DD",
        "reference": "required for user_input/practitioner"
      },
      "scope": "region/industry/time/sample; for regulation, applicable objects",
      "status": "verified|partial|unverified",
      "notes": "..."
    }
  ]
}
```

Rules:

- Public sources require `title`, `publisher`, `url`, `published` or `updated`, `accessed`.
- `user_fact` uses `source_type: user_input` + `reference`, no URL needed.
- `practitioner_experience` uses `source_type: practitioner` + `reference`, cannot be tagged `verified` as fact.
- `industry_data` only allows official/standard/peer_reviewed; `regulation` only official/standard.
- `vendor_claim` must tag the vendor source; `verified` only means "the vendor indeed states so", not that the claim is true.
- Default recency: technical capability 365 days, industry data 730 days, vendor claim 180 days, regulation 730 days (warns); exceeding only warns, asking for downgrade/explanation.
- Script does not open URLs; `verified` does not mean the script verified the content.

### Commands

```bash
python scripts/audit_evidence.py --example
python scripts/audit_evidence.py --input assets/evidence-ledger.example.json
python scripts/audit_evidence.py --input assets/evidence-ledger.example.json --format markdown
```

## 3. audit_brief.py

### Input

```json
{
  "project": "project name",
  "as_of": "2026-10-28",
  "business_context": {
    "confirmed": [{"id": "F1", "statement": "...", "source": "user/file/interview"}],
    "unknowns": [{"id": "U1", "question": "...", "why_it_matters": "...", "blocking": true}],
    "assumptions": [{"id": "A1", "statement": "...", "validation": "...", "impact_if_wrong": "..."}]
  },
  "stakeholders": [{"role": "..."}],
  "workflow": [{"step": 1, "actor": "...", "action": "...", "output": "...", "evidence": ["F1"]}],
  "needs": [{"statement": "...", "type": "stated_request|underlying_need|outcome", "evidence": ["F1"]}],
  "success_metrics": [{"name": "...", "baseline": "...", "target": "...", "measurement": "...", "source": "..."}],
  "constraints": {
    "tools": [{"name": "...", "status": "user_provided|observed|proposed", "constraint": "..."}],
    "data": [{"name": "...", "status": "available|partial|unavailable|unknown", "rights": "..."}],
    "compliance": [{"requirement": "...", "status": "confirmed|unknown", "source": "..."}]
  },
  "non_goals": ["not doing in phase 1..."],
  "open_questions": [{"question": "...", "owner": "...", "due": "..."}]
}
```

Checks:

- Whether facts/unknowns/assumptions have ID, source/verification/impact.
- Whether workflow `evidence` references existing IDs.
- Whether at least one evidenced `underlying_need` exists, and surface request vs business outcome are distinguished.
- Whether metrics have baseline/measurement; missing only warns, since early diagnosis may not have them.
- Whether tool status distinguishes `user_provided/observed` from `proposed`; a candidate tool appearing in a confirmed fact is an error.
- Whether data rights, compliance unknowns, and non-goals are recorded.
- `completeness` is structural completeness, not a business-quality or feasibility score.

### Commands

```bash
python scripts/audit_brief.py --example
python scripts/audit_brief.py --input assets/requirement-brief.example.json
python scripts/audit_brief.py --input assets/requirement-brief.example.json --format markdown
```

## 4. Tests

```bash
python -m unittest discover -s scripts/tests -v
```

Tests only verify script behavior, not any business/industry fact. Example files are all marked "fictional" and must not be cited as real cases or industry data.

## 5. Usage boundaries

- Don't put a script score into an external report without explaining the source, unknowns, and human judgment.
- Don't use script output to replace legal, security, finance, or business-owner decisions.
- Don't treat example data, placeholder URLs, or fictional organizations as real evidence.
- Don't treat `verified` as "content is true"; it only means the ledger metadata satisfied structural requirements.
- Desensitize sensitive info before input; scripts only read/write files locally, no network.
