#!/usr/bin/env python3
"""Advisory requirement-brief audit.

Checks completeness and anti-fabrication structure in a requirement brief. It
does not judge whether the business case is good; human review is required.
"""

from __future__ import annotations

import argparse
import re
import sys
from datetime import date
from typing import Any

from _common import (
    InputError,
    dump_json,
    load_json_file,
    markdown_table,
    parse_iso_date,
    require_text,
    rounded,
    status_label,
    write_text,
)

TOOL_VERSION = "1.0"

NEED_TYPES = {"stated_request", "underlying_need", "outcome"}
TOOL_STATUSES = {"user_provided", "observed", "proposed"}
DATA_STATUSES = {"available", "partial", "unavailable", "unknown"}
COMPLIANCE_STATUSES = {"confirmed", "unknown"}
PLACEHOLDERS = {
    "", "unknown", "tbd", "todo", "tbc", "to be confirmed", "to confirm",
    "to be determined", "待确认", "待定", "未知", "n/a", "na", "-",
}

# Language-aware fabrication markers: a "confirmed" fact must not be sourced
# from an assumption, speculation, or model generation.
ASSUMPTION_PATTERN = re.compile(
    r"(假设|推测|猜测|AI[\s-]?生成|模型生成|assum\w*|infer\w*|speculat\w*|AI-generated|model-generated|大模型生成)"
)
# Generic phrasing that hides an unverified claim behind "everyone knows".
GENERIC_PATTERN = re.compile(
    r"(通常|一般|普遍|行业都|众所周知|usual\w*|general\w*|common\w*|typical\w*|industry-wide|widely known|everyone knows)"
)
URL_PATTERN = re.compile(r"https?://")


def build_example() -> dict[str, Any]:
    return {
        "project": "Example: after-sales knowledge assistant (fictional)",
        "as_of": "2026-10-28",
        "business_context": {
            "summary": "Example only demonstrates the structure; all people, systems, and numbers are fictional.",
            "confirmed": [
                {
                    "id": "F1",
                    "statement": "Frontline after-sales staff must consult three internal knowledge sources simultaneously when handling inquiries.",
                    "source": "2026-10-28 interview, after-sales supervisor (fictional example)",
                },
                {
                    "id": "F2",
                    "statement": "The knowledge base is maintained by the policy team; updates are not announced uniformly.",
                    "source": "Document: knowledge-base maintenance notes (fictional example)",
                },
                {
                    "id": "F3",
                    "statement": "A single query currently requires switching across three pages on average.",
                    "source": "User statement (fictional example)",
                },
            ],
            "unknowns": [
                {
                    "id": "U1",
                    "question": "What is the update frequency of policy documents?",
                    "why_it_matters": "Determines the incremental indexing and version-tracking approach.",
                    "blocking": True,
                },
                {
                    "id": "U2",
                    "question": "Do different roles have differing document permissions?",
                    "why_it_matters": "Determines retrieval filtering and privilege-escalation risk control.",
                    "blocking": True,
                },
            ],
            "assumptions": [
                {
                    "id": "A1",
                    "statement": "Frontline staff prefer natural-language questions over field-based search.",
                    "validation": "Run a 5-person usability test; observe first-use and error recovery.",
                    "impact_if_wrong": "Must revert to structured search or a hybrid entry point, widening the scope.",
                }
            ],
        },
        "stakeholders": [
            {"role": "After-sales supervisor", "interest": "Reduce query time / complaints", "decision_right": "Scope & acceptance"},
            {"role": "Frontline agent", "interest": "Quickly find citable answers", "decision_right": "None"},
            {"role": "Policy team", "interest": "Clause accuracy / traceability", "decision_right": "Knowledge content"},
            {"role": "IT", "interest": "Permissions / integration / ops", "decision_right": "Technical approach"},
        ],
        "workflow": [
            {"step": 1, "actor": "Frontline", "action": "Receive customer inquiry", "output": "Problem description", "evidence": ["F1"]},
            {"step": 2, "actor": "Frontline", "action": "Query three knowledge sources", "output": "Candidate clauses", "evidence": ["F1", "F3"]},
            {"step": 3, "actor": "Frontline", "action": "Judge applicable clause and reply", "output": "Customer reply", "evidence": ["F1"]},
            {"step": 4, "actor": "Frontline / Supervisor", "action": "Log ticket and exceptions", "output": "Ticket record", "evidence": ["F3"]},
        ],
        "needs": [
            {
                "statement": "Build an after-sales knowledge assistant.",
                "type": "stated_request",
                "evidence": ["F1"],
            },
            {
                "statement": "After policy updates, frontline can quickly find citable, traceable clauses.",
                "type": "underlying_need",
                "evidence": ["F1", "F2"],
            },
            {
                "statement": "Reduce page switching and query wait, improving first-contact resolution rate.",
                "type": "outcome",
                "evidence": ["F3"],
            },
        ],
        "success_metrics": [
            {
                "name": "Single-query time",
                "baseline": "to be confirmed",
                "target": "to be confirmed by business",
                "measurement": "Ticket timestamps + observational sampling",
                "source": "to be confirmed",
            },
            {
                "name": "Answer citation accuracy",
                "baseline": "to be confirmed",
                "target": "to be confirmed by business",
                "measurement": "Manual labeling of 30-100 samples",
                "source": "to be confirmed",
            },
        ],
        "constraints": {
            "tools": [
                {"name": "Internal ticketing system", "status": "observed", "constraint": "Read-only interface to be confirmed"},
                {"name": "Existing knowledge base", "status": "observed", "constraint": "Permission model to be confirmed"},
                {"name": "vector retrieval", "status": "proposed", "constraint": "Candidate option, not current state"},
            ],
            "data": [
                {"name": "Policy documents", "status": "partial", "rights": "Internal use; cross-border / third-party use to be confirmed"},
                {"name": "Ticket records", "status": "available", "rights": "Internal use only (user statement)"},
            ],
            "compliance": [
                {"requirement": "Personal-data minimization", "status": "confirmed", "source": "User statement"},
                {"requirement": "Industry regulatory requirements", "status": "unknown", "source": ""},
            ],
        },
        "non_goals": ["No automatic refunds in the first phase", "No replacement of human approval in the first phase"],
        "open_questions": [
            {"question": "Policy document update frequency?", "owner": "Policy team", "due": "to be determined"},
            {"question": "Role-based permission differences?", "owner": "IT / Policy team", "due": "to be determined"},
        ],
    }


def add_finding(findings: list[dict[str, Any]], severity: str, code: str, message: str, section: str = "") -> None:
    findings.append({"severity": severity, "code": code, "section": section, "message": message})


def text_value(value: Any) -> str:
    return value.strip() if isinstance(value, str) else ""


def is_placeholder(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, bool):
        return True
    if isinstance(value, (int, float)):
        return False
    return text_value(value).lower() in PLACEHOLDERS


def refs(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value.strip()] if value.strip() else []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    return []


def audit(data: dict[str, Any]) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    project = require_text(data.get("project"), "project")
    as_of_raw = data.get("as_of")
    as_of = parse_iso_date(as_of_raw, "as_of")
    as_of_text = str(as_of_raw)

    context = data.get("business_context")
    if not isinstance(context, dict):
        add_finding(findings, "error", "missing_business_context", "Missing business_context.", "business_context")
        context = {}
    confirmed = context.get("confirmed", [])
    unknowns = context.get("unknowns", [])
    assumptions = context.get("assumptions", [])
    for name, value in (("confirmed", confirmed), ("unknowns", unknowns), ("assumptions", assumptions)):
        if not isinstance(value, list):
            add_finding(findings, "error", "invalid_context_list", f"business_context.{name} must be an array.", "business_context")
    confirmed = confirmed if isinstance(confirmed, list) else []
    unknowns = unknowns if isinstance(unknowns, list) else []
    assumptions = assumptions if isinstance(assumptions, list) else []

    ids: dict[str, str] = {}
    confirmed_rows: list[dict[str, Any]] = []
    for index, item in enumerate(confirmed):
        if not isinstance(item, dict):
            add_finding(findings, "error", "invalid_fact", f"confirmed[{index}] must be an object.", "confirmed")
            continue
        fact_id = text_value(item.get("id"))
        statement = text_value(item.get("statement"))
        source = text_value(item.get("source"))
        if not fact_id:
            add_finding(findings, "error", "missing_fact_id", f"confirmed[{index}] is missing id.", "confirmed")
            continue
        if fact_id in ids:
            add_finding(findings, "error", "duplicate_id", f"duplicate id: {fact_id}", "confirmed")
            continue
        ids[fact_id] = "confirmed"
        if not statement:
            add_finding(findings, "error", "missing_fact_statement", f"{fact_id} is missing statement.", "confirmed")
        if not source:
            add_finding(findings, "error", "missing_fact_source", f"{fact_id} is a confirmed fact but has no source.", "confirmed")
        elif ASSUMPTION_PATTERN.search(source):
            add_finding(findings, "warning", "assumption_as_fact", f"{fact_id}'s source contains assumption / speculation / AI-generated wording and should not be marked a confirmed fact.", "confirmed")
        if statement and GENERIC_PATTERN.search(statement) and not URL_PATTERN.search(source):
            add_finding(
                findings,
                "warning",
                "generic_claim",
                f"{fact_id} uses generic phrasing such as 'usually / generally', but has no verifiable source; state it as user-stated or verify it.",
                "confirmed",
            )
        if re.search(r"\d", statement) and not source:
            add_finding(findings, "error", "number_without_source", f"{fact_id} contains a number but has no source.", "confirmed")
        confirmed_rows.append({"id": fact_id, "statement": statement, "source": source})

    unknown_rows: list[dict[str, Any]] = []
    for index, item in enumerate(unknowns):
        if not isinstance(item, dict):
            add_finding(findings, "error", "invalid_unknown", f"unknowns[{index}] must be an object.", "unknowns")
            continue
        uid = text_value(item.get("id"))
        question = text_value(item.get("question"))
        why = text_value(item.get("why_it_matters"))
        if not uid:
            add_finding(findings, "error", "missing_unknown_id", f"unknowns[{index}] is missing id.", "unknowns")
            continue
        if uid in ids:
            add_finding(findings, "error", "duplicate_id", f"duplicate id: {uid}", "unknowns")
            continue
        ids[uid] = "unknown"
        if not question:
            add_finding(findings, "error", "missing_unknown_question", f"{uid} is missing question.", "unknowns")
        if not why:
            add_finding(findings, "error", "missing_unknown_why", f"{uid} is missing why_it_matters.", "unknowns")
        blocking_value = item.get("blocking", False)
        if not isinstance(blocking_value, bool):
            add_finding(findings, "error", "invalid_blocking", f"{uid}.blocking must be a boolean.", "unknowns")
            blocking_value = False
        blocking = blocking_value
        unknown_rows.append({"id": uid, "question": question, "why_it_matters": why, "blocking": blocking})

    assumption_rows: list[dict[str, Any]] = []
    for index, item in enumerate(assumptions):
        if not isinstance(item, dict):
            add_finding(findings, "error", "invalid_assumption", f"assumptions[{index}] must be an object.", "assumptions")
            continue
        aid = text_value(item.get("id"))
        statement = text_value(item.get("statement"))
        validation = text_value(item.get("validation"))
        impact = text_value(item.get("impact_if_wrong"))
        if not aid:
            add_finding(findings, "error", "missing_assumption_id", f"assumptions[{index}] is missing id.", "assumptions")
            continue
        if aid in ids:
            add_finding(findings, "error", "duplicate_id", f"duplicate id: {aid}", "assumptions")
            continue
        ids[aid] = "assumption"
        if not statement:
            add_finding(findings, "error", "missing_assumption_statement", f"{aid} is missing statement.", "assumptions")
        if not validation:
            add_finding(findings, "error", "missing_assumption_validation", f"{aid} is missing validation.", "assumptions")
        if not impact:
            add_finding(findings, "error", "missing_assumption_impact", f"{aid} is missing impact_if_wrong.", "assumptions")
        assumption_rows.append({"id": aid, "statement": statement, "validation": validation, "impact": impact})

    if not confirmed_rows:
        add_finding(findings, "error", "no_confirmed_facts", "At least one confirmed fact is required.", "business_context")
    if not unknown_rows:
        add_finding(findings, "warning", "no_unknowns", "No unknowns; a diagnosis normally has at least one open fact.", "business_context")
    if not assumption_rows:
        add_finding(findings, "warning", "no_assumptions", "No assumptions; confirm there really are none to be validated.", "business_context")

    stakeholders = data.get("stakeholders", [])
    if not isinstance(stakeholders, list) or not stakeholders:
        add_finding(findings, "error", "missing_stakeholders", "At least one stakeholder is required.", "stakeholders")
        stakeholders = []
    for index, item in enumerate(stakeholders):
        if not isinstance(item, dict) or not text_value(item.get("role")):
            add_finding(findings, "error", "invalid_stakeholder", f"stakeholders[{index}] needs a role.", "stakeholders")

    workflow = data.get("workflow", [])
    if not isinstance(workflow, list) or not workflow:
        add_finding(findings, "error", "missing_workflow", "At least one workflow step is required.", "workflow")
        workflow = []
    step_numbers: list[int] = []
    for index, item in enumerate(workflow):
        if not isinstance(item, dict):
            add_finding(findings, "error", "invalid_workflow_step", f"workflow[{index}] must be an object.", "workflow")
            continue
        step_no = item.get("step", index + 1)
        if isinstance(step_no, bool) or not isinstance(step_no, int):
            add_finding(findings, "error", "invalid_step_number", f"workflow[{index}].step must be an integer.", "workflow")
        else:
            step_numbers.append(step_no)
        for field in ("actor", "action", "output"):
            if not text_value(item.get(field)):
                add_finding(findings, "error", "missing_workflow_field", f"workflow[{index}] is missing {field}.", "workflow")
        evidence = refs(item.get("evidence"))
        if not evidence:
            add_finding(findings, "warning", "workflow_no_evidence", f"workflow step {step_no} has no evidence reference.", "workflow")
        for ref in evidence:
            if ref not in ids:
                add_finding(findings, "error", "unknown_evidence_ref", f"workflow references a non-existent evidence id: {ref}", "workflow")
    if step_numbers != list(range(1, len(step_numbers) + 1)):
        add_finding(findings, "warning", "workflow_step_order", "workflow.step should be numbered consecutively from 1.", "workflow")
    if 0 < len(workflow) < 3:
        add_finding(findings, "warning", "short_workflow", "Fewer than 3 steps; confirm handoffs / exceptions / fallbacks are not missing.", "workflow")

    needs = data.get("needs", [])
    if not isinstance(needs, list) or not needs:
        add_finding(findings, "error", "missing_needs", "At least one need is required.", "needs")
        needs = []
    need_types: list[str] = []
    for index, item in enumerate(needs):
        if not isinstance(item, dict):
            add_finding(findings, "error", "invalid_need", f"needs[{index}] must be an object.", "needs")
            continue
        statement = text_value(item.get("statement"))
        need_type = text_value(item.get("type"))
        evidence = refs(item.get("evidence"))
        if not statement:
            add_finding(findings, "error", "missing_need_statement", f"needs[{index}] is missing statement.", "needs")
        if need_type not in NEED_TYPES:
            add_finding(findings, "error", "invalid_need_type", f"needs[{index}].type must be {', '.join(sorted(NEED_TYPES))}.", "needs")
        else:
            need_types.append(need_type)
        if need_type == "underlying_need" and not evidence:
            add_finding(findings, "error", "need_without_evidence", f"underlying need '{statement or index}' has no evidence reference.", "needs")
        elif not evidence:
            add_finding(findings, "warning", "need_no_evidence", f"needs[{index}] has no evidence reference.", "needs")
        for ref in evidence:
            if ref not in ids:
                add_finding(findings, "error", "unknown_need_ref", f"needs references a non-existent evidence id: {ref}", "needs")
    if "stated_request" not in need_types:
        add_finding(findings, "warning", "no_stated_request", "No user's surface request is recorded, making 'request vs. real need' comparison hard.", "needs")
    if "underlying_need" not in need_types:
        add_finding(findings, "error", "no_underlying_need", "At least one underlying_need is required.", "needs")
    if "outcome" not in need_types:
        add_finding(findings, "warning", "no_outcome", "No business outcome is recorded.", "needs")

    metrics = data.get("success_metrics", [])
    if not isinstance(metrics, list) or not metrics:
        add_finding(findings, "error", "missing_metrics", "At least one success_metric is required.", "success_metrics")
        metrics = []
    incomplete_metrics = 0
    for index, item in enumerate(metrics):
        if not isinstance(item, dict):
            add_finding(findings, "error", "invalid_metric", f"success_metrics[{index}] must be an object.", "success_metrics")
            continue
        name = text_value(item.get("name"))
        if not name:
            add_finding(findings, "error", "missing_metric_name", f"success_metrics[{index}] is missing name.", "success_metrics")
        for field in ("baseline", "target", "measurement"):
            if is_placeholder(item.get(field)):
                incomplete_metrics += 1
                add_finding(
                    findings,
                    "warning",
                    "metric_incomplete",
                    f"Metric '{name or index}' {field} is still to be confirmed; without a baseline you cannot prove improvement.",
                    "success_metrics",
                )
        if not text_value(item.get("source")):
            add_finding(findings, "warning", "metric_no_source", f"Metric '{name or index}' has no data source.", "success_metrics")

    constraints = data.get("constraints", {})
    if not isinstance(constraints, dict):
        add_finding(findings, "error", "invalid_constraints", "constraints must be an object.", "constraints")
        constraints = {}

    tools = constraints.get("tools", [])
    if not isinstance(tools, list) or not tools:
        add_finding(findings, "warning", "no_tools", "No existing tools / systems recorded; confirm none are relied upon.", "constraints.tools")
        tools = []
    tool_status_by_name: dict[str, set[str]] = {}
    proposed_names: list[str] = []
    for index, item in enumerate(tools):
        if not isinstance(item, dict):
            add_finding(findings, "error", "invalid_tool", f"constraints.tools[{index}] must be an object.", "constraints.tools")
            continue
        name = text_value(item.get("name"))
        status = text_value(item.get("status"))
        if not name:
            add_finding(findings, "error", "missing_tool_name", f"constraints.tools[{index}] is missing name.", "constraints.tools")
            continue
        if status not in TOOL_STATUSES:
            add_finding(
                findings,
                "error",
                "invalid_tool_status",
                f"Tool '{name}' status must be user_provided / observed / proposed.",
                "constraints.tools",
            )
            continue
        tool_status_by_name.setdefault(name, set()).add(status)
        if status == "proposed":
            proposed_names.append(name)
    for name, statuses in tool_status_by_name.items():
        if len(statuses) > 1:
            add_finding(findings, "warning", "conflicting_tool_status", f"Tool '{name}' has multiple statuses: {sorted(statuses)}.", "constraints.tools")
        if "proposed" in statuses and "observed" in statuses:
            add_finding(findings, "error", "proposed_is_current", f"Tool '{name}' is marked both proposed and observed; separate candidate from current state.", "constraints.tools")

    fabrication_risks: list[str] = []
    for name in proposed_names:
        for fact in confirmed_rows:
            if name and name in fact["statement"]:
                message = f"Candidate tool '{name}' appears in confirmed fact '{fact['id']}'; do not write a proposal as if it were current state."
                fabrication_risks.append(message)
                add_finding(findings, "error", "proposed_tool_in_fact", message, "confirmed")

    data_items = constraints.get("data", [])
    if not isinstance(data_items, list) or not data_items:
        add_finding(findings, "warning", "no_data", "No data status recorded; confirm no data is needed or none is missing.", "constraints.data")
        data_items = []
    for index, item in enumerate(data_items):
        if not isinstance(item, dict):
            add_finding(findings, "error", "invalid_data", f"constraints.data[{index}] must be an object.", "constraints.data")
            continue
        name = text_value(item.get("name"))
        status = text_value(item.get("status"))
        if not name:
            add_finding(findings, "error", "missing_data_name", f"constraints.data[{index}] is missing name.", "constraints.data")
        if status not in DATA_STATUSES:
            add_finding(
                findings,
                "error",
                "invalid_data_status",
                f"Data '{name or index}' status must be available / partial / unavailable / unknown.",
                "constraints.data",
            )
        elif status in {"unknown", "unavailable"}:
            add_finding(findings, "warning", "data_not_ready", f"Data '{name or index}' status is {status}; this limits feasibility.", "constraints.data")
        if not text_value(item.get("rights")):
            add_finding(findings, "warning", "data_rights_missing", f"Data '{name or index}' has no usage rights / boundaries recorded.", "constraints.data")

    compliance = constraints.get("compliance", [])
    if not isinstance(compliance, list) or not compliance:
        add_finding(findings, "warning", "no_compliance", "No compliance requirements recorded; confirm none apply rather than omitting them.", "constraints.compliance")
        compliance = []
    for index, item in enumerate(compliance):
        if not isinstance(item, dict):
            add_finding(findings, "error", "invalid_compliance", f"constraints.compliance[{index}] must be an object.", "constraints.compliance")
            continue
        requirement = text_value(item.get("requirement"))
        status = text_value(item.get("status"))
        if not requirement:
            add_finding(findings, "error", "missing_compliance_requirement", f"constraints.compliance[{index}] is missing requirement.", "constraints.compliance")
        if status not in COMPLIANCE_STATUSES:
            add_finding(findings, "error", "invalid_compliance_status", "Compliance item status must be confirmed / unknown.", "constraints.compliance")
        elif status == "unknown":
            add_finding(findings, "warning", "compliance_unknown", f"Compliance item '{requirement or index}' is still unknown.", "constraints.compliance")

    non_goals = data.get("non_goals", [])
    if not isinstance(non_goals, list) or not non_goals:
        add_finding(findings, "error", "missing_non_goals", "At least one non_goal (what is out of scope for phase 1) is required.", "non_goals")
        non_goals = []

    open_questions = data.get("open_questions", [])
    if open_questions is not None and not isinstance(open_questions, list):
        add_finding(findings, "error", "invalid_open_questions", "open_questions must be an array.", "open_questions")
        open_questions = []
    blocking_unknowns = [u for u in unknown_rows if u.get("blocking")]
    if blocking_unknowns and not open_questions:
        add_finding(findings, "warning", "blocking_without_question", "There are blocking unknowns but no open_questions.", "open_questions")

    checks = [
        ("confirmed_facts", "At least one confirmed fact", len(confirmed_rows) > 0),
        ("unknowns", "At least one open item", len(unknown_rows) > 0),
        ("assumptions", "At least one assumption with validation", len(assumption_rows) > 0),
        ("stakeholders", "Roles and decision owners", len(stakeholders) > 0),
        ("workflow", "At least three workflow steps", len(workflow) >= 3),
        ("underlying_need", "At least one evidenced real need", any(n.get("type") == "underlying_need" for n in needs) if all(isinstance(n, dict) for n in needs) else False),
        ("metrics", "At least one success metric", len(metrics) > 0),
        ("baseline", "Metrics have baseline / measurement", incomplete_metrics == 0 and len(metrics) > 0),
        ("tools", "Tool status separates current from candidate", len(tools) > 0 and not fabrication_risks),
        ("data", "Data status and rights", len(data_items) > 0),
        ("compliance", "Compliance items recorded", len(compliance) > 0),
        ("non_goals", "Explicit non-goals", len(non_goals) > 0),
    ]
    passed = sum(1 for _, _, ok in checks if ok)
    completeness = rounded(passed / len(checks) * 100, 1)

    errors = [f for f in findings if f["severity"] == "error"]
    warnings = [f for f in findings if f["severity"] == "warning"]
    if errors:
        verdict = "blocking_issues"
        verdict_label = "Blocking issues need fixing"
    elif warnings:
        verdict = "pass_with_warnings"
        verdict_label = "Structure passes, but items need human review"
    else:
        verdict = "structure_ok"
        verdict_label = "Structure complete (human still needs to judge quality)"

    return {
        "tool": "audit_brief",
        "tool_version": TOOL_VERSION,
        "advisory_only": True,
        "not_a_final_decision": True,
        "project": project,
        "as_of": as_of_text,
        "verdict": verdict,
        "verdict_label": verdict_label,
        "completeness": completeness,
        "summary": {
            "confirmed": len(confirmed_rows),
            "unknowns": len(unknown_rows),
            "blocking_unknowns": len(blocking_unknowns),
            "assumptions": len(assumption_rows),
            "workflow_steps": len(workflow),
            "needs": len(needs),
            "metrics": len(metrics),
            "errors": len(errors),
            "warnings": len(warnings),
        },
        "checks": [{"key": k, "label": label, "passed": ok} for k, label, ok in checks],
        "findings": findings,
        "fabrication_risks": fabrication_risks,
        "disclaimer": (
            "This check only evaluates the requirement brief's structural completeness and anti-fabrication "
            "markers; it does not judge business value, does not verify facts, and does not replace the final "
            "go/no-go decision. Every 'confirmed' fact must still be traceable to user-provided original material."
        ),
    }


def render_markdown(result: dict[str, Any]) -> str:
    summary = result["summary"]
    lines = [
        "# Requirement Brief Check (Advisory)",
        "",
        f"> {result['disclaimer']}",
        "",
        f"- Project: {result['project']}",
        f"- As of: {result['as_of']}",
        f"- Conclusion: **{result['verdict_label']}** (`{result['verdict']}`)",
        f"- Structural completeness: **{result['completeness']:.1f}%** (not a quality score, not a feasibility score)",
        f"- Facts / unknowns / assumptions: {summary['confirmed']} / {summary['unknowns']} (blocking {summary['blocking_unknowns']}) / {summary['assumptions']}",
        f"- Errors: {summary['errors']}; warnings: {summary['warnings']}",
        "",
        "## Completeness Checks",
        "",
        markdown_table(
            ["Check", "Result"],
            [[c["label"], "Pass" if c["passed"] else "Missing"] for c in result["checks"]],
        ),
    ]
    if result["fabrication_risks"]:
        lines.extend(["", "## Fabrication Risks", ""])
        lines.extend([f"- {r}" for r in result["fabrication_risks"]])
    if result["findings"]:
        lines.extend(["", "## Findings", ""])
        lines.append(
            markdown_table(
                ["Severity", "Section", "Code", "Message"],
                [
                    [f["severity"], f["section"] or "-", f["code"], f["message"]]
                    for f in result["findings"]
                ],
            )
        )
    else:
        lines.extend(["", "## Findings", "", "No structural issues found. A human must still judge evidence quality and business value."])

    lines.extend(
        [
            "",
            "## Human Review Focus",
            "",
            "- Can every 'confirmed' fact be traced to original material / interview notes?",
            "- Were candidate tools, industry common sense, or your suggestions written as current state?",
            "- Do real needs have evidence, not just the user's surface request?",
            "- Do metrics have a baseline / measurement method, or only a target slogan?",
            "- Do blocking unknowns have an owner and a due date?",
        ]
    )
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Check the requirement brief's structural completeness and anti-fabrication markers; does not judge business value.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python audit_brief.py --example\n"
            "  python audit_brief.py --input assets/requirement-brief.example.json --format markdown\n"
        ),
    )
    parser.add_argument("--input", help="Input JSON file")
    parser.add_argument("--format", choices=("json", "markdown"), default="json", help="Output format")
    parser.add_argument("--output", help="Write to file; print to stdout if omitted")
    parser.add_argument("--example", action="store_true", help="Print example brief JSON")
    args = parser.parse_args(argv)

    try:
        if args.example:
            if args.input:
                parser.error("--example cannot be used together with --input")
            write_text(args.output, dump_json(build_example()))
            return 0
        if not args.input:
            parser.error("need --input, or use --example to see the brief structure")
        data = load_json_file(args.input)
        result = audit(data)
        content = dump_json(result) if args.format == "json" else render_markdown(result)
        write_text(args.output, content)
        return 1 if result["summary"]["errors"] else 0
    except InputError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
